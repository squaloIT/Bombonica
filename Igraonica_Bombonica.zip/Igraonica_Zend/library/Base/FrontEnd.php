<?php

class Base_FrontEnd extends Zend_Controller_Action {

    protected $ulogovan = false;
    protected $loglink;
    protected $logtext;
    public $session;
    public function init() {
        
    }

    public function indexAction() {
        
    }

    public function ulogovan() {
        $auth = Zend_Auth::getInstance();
        $this->ulogovan = $auth->hasIdentity();
        $this->session= new Zend_Auth_Storage_Session();
        if($this->session->read()!=null && !empty($this->session->read())){
            $this->_helper->layout()->idUloga=  $this->session->read()->id_uloga;
        }
    }

}
