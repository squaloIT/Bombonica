<?php

class EventsController extends Base_FrontEnd {

    public function init() {
        $this->view->headTitle()->append(" Events");
        //Zend_Loader_Autoloader::autoload("MyLoginForm");
        $this->ulogovan();
    }

    public function indexAction() {
        $this->view->assign("div_class_for_every_page", "events");
        if (!$this->ulogovan) {
            $form = new Application_Form_MyLoginForm();
            $this->_helper->layout()->login = $form;
        } else {
            $form = new Application_Form_MyFormLogout();
            $this->_helper->layout()->logout = $form;
        }
        $eventsMapper = new Application_Model_AktivnostMapper();
        $allEventsFromDB = $eventsMapper->fetchAll();
        $topThree = $eventsMapper->fetchTopThree();
        
        $this->view->topThree = $topThree;
        $this->view->events = $allEventsFromDB;
    }

}
