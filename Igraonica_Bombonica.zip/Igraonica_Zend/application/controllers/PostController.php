<?php

class PostController extends Base_FrontEnd {

    public function init() {
        $this->view->headTitle()->append(" Post");
        $this->ulogovan();
    }

    public function indexAction() {
        $this->redirect('/Index');
    }

    public function eventAction() {
        $idParam = $this->getParam('id');
        $idParam = intval($idParam);

        if (null != $idParam && is_int($idParam)) {
            $this->view->assign("div_class_for_every_page", 'events');

            if (!$this->ulogovan) {
                $form = new Application_Form_MyLoginForm();
                $this->_helper->layout()->login = $form;
            } else {
                $form = new Application_Form_MyFormLogout();
                $this->_helper->layout()->logout = $form;
            }
            $event = new Application_Model_Aktivnost();
            $eventsMapper = new Application_Model_AktivnostMapper();
            $EventFromDB = $eventsMapper->find($idParam, $event);
            $this->view->events = $EventFromDB;

            $topThree = $eventsMapper->fetchTopThree();
            //print_r($topThree);
            $this->view->topThree = $topThree;
        } else {
            $this->redirect("/Index");
        }
    }

}
