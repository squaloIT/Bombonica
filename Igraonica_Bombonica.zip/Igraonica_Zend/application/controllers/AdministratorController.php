<?php

class AdministratorController extends Base_FrontEnd {

    private $client = null;

    public function init() {
        $this->ulogovan();
        $this->client = new Zend_Rest_Client('http://restApiServer/');
        $this->view->headScript()->appendFile("/js/my.js");
    }

    public function indexAction() {
        $this->view->assign("div_class_for_every_page", 'about');

        if (!$this->ulogovan && $this->session->read()->id_uloga != 1) {
            $this->redirect("/Index");
        }
        $links = array(
            array('key' => "/Administrator/aktivnost", 'value' => "Managing Events"),
            array('key' => "/Administrator/galerija", 'value' => "Managing Gallery"),
            array('key' => "/Administrator/slika", 'value' => "Managing Pictures in Gallery"),
            array('key' => "/Administrator/datum", 'value' => "Managing Dates"),
            array('key' => "/Administrator/rezervacije", 'value' => "Managing Reservations"),
            array('key' => "/Administrator/termin", 'value' => "Managing Periods"),
            array('key' => "/Administrator/uloga", 'value' => "Managing Roles"),
        );

        $this->view->links = $links;
    }

    public function ulogaAction() {
        $this->view->assign("div_class_for_every_page", 'about');
        $request = $this->getRequest();
        if (!$this->ulogovan && $this->session->read()->id_uloga != 1) {
            $this->redirect("/Index");
        }
        $tip = $request->getParam("tip");

        if ($tip == "unos") {
            $formUloga = new Application_Form_MyFormAdminUloga();

            if ($request->isPost() && $formUloga->isValid($request->getPost())) {

                $naziv = $request->getPost("tbUloga");
                $requestApi = $this->client->restPost('/RestApi', array('type' => 'roles', 'naziv' => $naziv));
                $response = $requestApi->getRawBody();
                $jsonResponse = Zend_Json_Decoder::decode($response);

                if ($jsonResponse['success'] == 1) {
                    $this->view->resultMessage = $jsonResponse['body'];
                } else {
                    $this->view->resultMessage = $jsonResponse['body'];
                }
            } else {
                $this->view->formUloga = $formUloga;
            }
        } elseif ($tip == "pregled") {

            $requestApi = $this->client->restGet('/RestApi', array('type' => 'roles'));
            $response = $requestApi->getRawBody();
            $jsonResponse = Zend_Json_Decoder::decode($response);
            if ($jsonResponse['success'] == 1) {
                $this->view->roleTable = $jsonResponse['body'];
            } else {
                $this->view->roleTable = $jsonResponse['body'];
            }
        } elseif ($tip == "izbrisi") {
            $id = trim($request->getParam("id"));
            $requestApi = $this->client->restDelete("/RestApi/type/roles/id/" . $id);
            $response = $requestApi->getRawBody();
            $jsonResponse = Zend_Json_Decoder::decode($response);
            if (!empty($jsonResponse)) {
                if ($jsonResponse['success'] == 1) {
                    $this->redirect("/Administrator/uloga/tip/pregled");
                } else {
                    $this->view->resultMessage = $jsonResponse['body'];
                }
            }
        } elseif ($tip == "izmeni") {
            $id = trim($request->getParam("id"));
            $ulogaMapper = new Application_Model_UlogaMapper();
            $uloga = new Application_Model_Uloga();
            $ulogaMapper->find($id, $uloga);
            $formUloga = new Application_Form_MyFormAdminUloga(null, $uloga->getNaziv());
            $hiddenIdElement = new Zend_Form_Element_Hidden("hiddenId");
            $hiddenIdElement->setValue($id);

            $formUloga->addElement($hiddenIdElement);
            if ($request->isPost() && $formUloga->isValid($request->getPost())) {
                $naziv = $request->getPost("tbUloga");
                $id_uloga = $request->getPost("hiddenId");
                $requestApi = $this->client->restPost('/RestApi', array('type' => 'roles', 'naziv' => $naziv, 'id_uloga' => $id_uloga));
                $response = $requestApi->getRawBody();
                $jsonResponse = Zend_Json_Decoder::decode($response);

                if ($jsonResponse['success'] == 1) {
                     $this->redirect("/Administrator/uloga/tip/pregled");
                } else {
                    $this->view->resultMessage = $jsonResponse['body'];
                }
            } else {
                $this->view->formUloga = $formUloga;
            }
        } else {
            $links = array(
                array('key' => "/Administrator/uloga/tip/unos", 'value' => "Insert Role"),
                array('key' => "/Administrator/uloga/tip/pregled", 'value' => "View, Update or Delete Roles"),
            );

            $this->view->links = $links;
        }
    }

    public function terminAction() {
        $this->view->assign("div_class_for_every_page", 'about');
        $request = $this->getRequest();
        if (!$this->ulogovan && $this->session->read()->id_uloga != 1) {
            $this->redirect("/Index");
        }
        $tip = $request->getParam("tip");
        if ($tip == "unos") {
            $formTermin = new Application_Form_MyFormAdminTermin();

            if ($request->isPost() && $formTermin->isValid($request->getPost())) {
                $termin = $request->getPost("tbTermin");
                $requestApi = $this->client->restPost('/RestApi', array('type' => 'period', 'trajanje_termina' => $termin));
                $response = $requestApi->getRawBody();
                $jsonResponse = Zend_Json_Decoder::decode($response);
                print $jsonResponse['success'];

                if ($jsonResponse['success'] == 1) {
                    $this->view->resultMessage = $jsonResponse['body'];
                } else {
                    $this->view->resultMessage = $jsonResponse['body'];
                }
            } else {
                $this->view->formTermin = $formTermin;
            }
        } elseif ($tip == "pregled") {

            $requestApi = $this->client->restGet('/RestApi', array('type' => 'period'));
            $response = $requestApi->getRawBody();
            $jsonResponse = Zend_Json_Decoder::decode($response);
            if ($jsonResponse['success'] == 1) {
                $this->view->terminTable = $jsonResponse['body'];
            } else {
                $this->view->terminTable = $jsonResponse['body'];
            }
        } elseif ($tip == "izbrisi") {
            $id = trim($request->getParam("id"));
            $requestApi = $this->client->restDelete("/RestApi/type/period/id/" . $id);
            $response = $requestApi->getRawBody();
            $jsonResponse = Zend_Json_Decoder::decode($response);
            if (!empty($jsonResponse)) {
                if ($jsonResponse['success'] == 1) {
                    $this->redirect("/Administrator/termin/tip/pregled");
                } else {
                    $this->view->resultMessage = $jsonResponse['body'];
                }
            }
        } elseif ($tip == "izmeni") {
            $id = trim($request->getParam("id"));
            $terminMapper = new Application_Model_TerminMapper();
            $termin = new Application_Model_Termin();
            $terminMapper->find($id, $termin);
            //$formTermin = new Application_Form_MyFormAdminTermin();
            $form = new Zend_Form();
            $form->setMethod("post");
            $form->setAction("/Administrator/termin/tip/izmeni");
            $form->setName("TerminForm");
            $form->setDescription("Adding new period");
            $form->setAttrib("class", "periodForm");
            $terminTextElement = new Zend_Form_Element_Text("tbTermin");
            $terminTextElement->setLabel("Termin example: 15:00 - 18:00");
            $terminTextElement->setRequired(true);
            $terminTextElement->addValidator("NotEmpty", true, array("messages" => "Period is mandatory"));
            $terminTextElement->addValidator(new Zend_Validate_Regex("/^[0-9]{2}:[0-9]{2} - [0-9]{2}:[0-9]{2}$/"), true)
                    ->addErrorMessage("Period example 09:00 - 12:00.");
            //$element->setAttrib($attribs);
            $terminTextElement->setValue($termin->getTrajanje_termina());
            $terminTextElement->addFilter(new Zend_Filter_HtmlEntities());
            $terminTextElement->addFilter(new Zend_Filter_StripTags());
            $terminTextElement->addFilter(new Zend_Filter_StringTrim());

            $submitFormElement = new Zend_Form_Element_Submit("btnSubmit");
            $submitFormElement->setLabel("Update");
            $submitFormElement->setAttribs(array("class" => "btnSubmit"));
            $hiddenEl = new Zend_Form_Element_Hidden("hiddenId");
            $hiddenEl->setValue($request->getParam("id"));

            $form->addElement($terminTextElement);
            $form->addElement($hiddenEl);
            $form->addElement($submitFormElement);

            if ($request->isPost() && $form->isValid($request->getPost())) {
                $termin = $request->getPost("tbTermin");
                $id_termin = $request->getPost("hiddenId");
                $requestApi = $this->client->restPost('/RestApi', array('type' => 'period', 'trajanje_termina' => $termin, 'id_termin' => $id_termin));
                $response = $requestApi->getRawBody();
                $jsonResponse = Zend_Json_Decoder::decode($response);
                print $jsonResponse['success'];

                if ($jsonResponse['success'] == 1) {
                    $this->redirect("/Administrator/termin/tip/pregled");
                } else {
                    $this->view->resultMessage = $jsonResponse['body'];
                }
            } else {

                $this->view->formTermin = $form;
            }
        } else {
            $links = array(
                array('key' => "/Administrator/termin/tip/unos", 'value' => "Insert birthday periods"),
                array('key' => "/Administrator/termin/tip/pregled", 'value' => "View, Update or Delete birthday periods"),
            );
            $this->view->links = $links;
        }
    }

    public function rezervacijeAction() {
        $this->view->assign("div_class_for_every_page", 'about');
        $request = $this->getRequest();
        if (!$this->ulogovan && $this->session->read()->id_uloga != 1) {
            $this->redirect("/Index");
        }
        $tip = $request->getParam("tip");
        if ($tip == "unos") {

            $datumMapper = new Application_Model_DatumRezervacijaMapper();
            $datumi = $datumMapper->fetchDatum();
            $formReservation = new Application_Form_MyFormAdminReservation($datumi);
            $idTermin = trim(addslashes($request->getPost("ddlTermin")));
            $idDatum = trim(addslashes($request->getPost("ddlDatum")));

            if ($request->isPost()) {
                if ($idTermin != 0 && intval($idTermin) && intval($idDatum) && $idDatum != 0) {
                    $formReservation->getTerminElement()->setRegisterInArrayValidator(false);
                    $formReservation->getDatumElement()->setRegisterInArrayValidator(false);

                    if ($formReservation->isValid($request->getPost())) {

                        $slavljenik = trim(addslashes($request->getPost("tbSlavljenik")));
                        $email = trim(addslashes($request->getPost("tbEmail")));
                        $username = trim(addslashes($request->getPost("tbUsername")));
                        $requestApi = $this->client->restPost('/RestApi', array('type' => 'reservation',
                            'username' => $username,
                            'email' => $email,
                            'slavljenik' => $slavljenik,
                            'id_termin' => $idTermin,
                            'id_datum' => $idDatum
                        ));
                        $response = $requestApi->getRawBody();
                        $jsonResponse = Zend_Json_Decoder::decode($response);
                        print $jsonResponse['success'];

                        if ($jsonResponse['success'] == 1) {
                            $this->view->resultMessage = $jsonResponse['body'];
                        } else {
                            $this->view->resultMessage = $jsonResponse['body'];
                        }
                    }
                }
            } else {
                $this->view->formReservation = $formReservation;
            }
        } elseif ($tip == "pregled") {

            $requestApi = $this->client->restGet('/RestApi', array('type' => 'reservation'));
            $response = $requestApi->getRawBody();
            $jsonResponse = Zend_Json_Decoder::decode($response);

            if ($jsonResponse['success'] == 1) {
                $this->view->reservationTable = $jsonResponse['body'];
            } else {
                $this->view->reservationTable = $jsonResponse['body'];
            }
        } elseif ($tip == "izbrisi") {
            $id = trim($request->getParam("id"));
            $requestApi = $this->client->restDelete("/RestApi/type/reservation/id/" . $id);
            $response = $requestApi->getRawBody();
            $jsonResponse = Zend_Json_Decoder::decode($response);
            if (!empty($jsonResponse)) {
                if ($jsonResponse['success'] == 1) {
                    $this->redirect("/Administrator/rezervacije/tip/pregled");
                } else {
                    $this->view->resultMessage = $jsonResponse['body'];
                }
            }
        } elseif ($tip == "izmeni") {
            $id = trim($request->getParam("id"));
            $idRezervacije = intval($id);
            $rezervacije = new Application_Model_Rezervacije();
            $rezervacijeMapper = new Application_Model_RezervacijeMapper();
            $rezervacijeMapper->find($idRezervacije, $rezervacije);
            $update = array(
                'slavljenik' => $rezervacije->getSlavljenik(),
                'email' => $rezervacije->getEmail(),
                'username' => $rezervacije->getUsername(),
                'id_rezervacije' => $idRezervacije
            );

            $datumMapper = new Application_Model_DatumRezervacijaMapper();
            $datumi = $datumMapper->fetchDatum();
            $formReservation = new Application_Form_MyFormAdminReservation($datumi, null, $update);

            $idTermin = trim(addslashes($request->getPost("ddlTermin")));
            $idDatum = trim(addslashes($request->getPost("ddlDatum")));
            if ($request->isPost()) {
                if ($idTermin !== 0 && intval($idTermin) && intval($idDatum) && $idDatum !== 0) {
                    $formReservation->getTerminElement()->setRegisterInArrayValidator(false);
                    $formReservation->getDatumElement()->setRegisterInArrayValidator(false);

                    if ($formReservation->isValid($request->getPost())) {

                        $slavljenik = trim(addslashes($request->getPost("tbSlavljenik")));
                        $email = trim(addslashes($request->getPost("tbEmail")));
                        $username = trim(addslashes($request->getPost("tbUsername")));
                        $id_rez = trim(addslashes($request->getPost("hiddenId")));
                        $requestApi = $this->client->restPost('/RestApi', array(
                            'type' => 'reservation',
                            'username' => $username,
                            'email' => $email,
                            'slavljenik' => $slavljenik,
                            'id_termin' => $idTermin,
                            'id_datum' => $idDatum,
                            'id_rezervacije' => $id_rez
                        ));
                        //print_r($slavljenik." ".$email." ".$username." rez: ".$id_rez." termin: ".$idTermin." ".$idDatum);
                        $response = $requestApi->getRawBody();
                        $jsonResponse = Zend_Json_Decoder::decode($response);
                        print $jsonResponse['success'];

                        if ($jsonResponse['success'] == 1) {
                            $this->redirect("/Administrator/rezervacije/tip/pregled");
                        } else {
                            $this->view->resultMessage = $jsonResponse['body'];
                        }
                    }
                }
            } else {
                $this->view->formReservation = $formReservation;
            }
        } else {
            $links = array(
                array('key' => "/Administrator/rezervacije/tip/unos", 'value' => "Insert Reservation"),
                array('key' => "/Administrator/rezervacije/tip/pregled", 'value' => "View, Update or Delete Reservatons"),
            );

            $this->view->links = $links;
        }
    }

    public function datumAction() {
        $this->view->assign("div_class_for_every_page", 'about');
        $request = $this->getRequest();
        if (!$this->ulogovan && $this->session->read()->id_uloga != 1) {
            $this->redirect("/Index");
        }
        $tip = $request->getParam("tip");
        if ($tip == "unos") {
            //$formDatum = new Application_Form_MyFormAdminDatum();
            if ($request->isPost()) {// && $formDatum->isValid($request->getPost())) {
                $date = $request->getPost("tbDate");
                if ($date !== null) {
                    $dateForInsert = $this->dateRebuilder($date); //Pozivanje one funkcije odozdo
                    $requestApi = $this->client->restPost('/RestApi', array('type' => 'date', 'datum_rezervacije' => $dateForInsert));
                    $response = $requestApi->getRawBody();
                    $jsonResponse = Zend_Json_Decoder::decode($response);
                    if ($jsonResponse['success'] == 1) {
                        $this->view->resultMessage = $jsonResponse['body'];
                    } else {
                        $this->view->resultMessage = $jsonResponse['body'];
                    }
                }
            } else {
                $this->view->formDatum = 1; //$formDatum;
            }
        } elseif ($tip == "pregled") {

            $requestApi = $this->client->restGet('/RestApi', array('type' => 'date'));
            $response = $requestApi->getRawBody();
            $jsonResponse = Zend_Json_Decoder::decode($response);
            if ($jsonResponse['success'] == 1) {
                $this->view->dateTable = $jsonResponse['body'];
            } else {
                $this->view->dateTable = $jsonResponse['body'];
            }
        } elseif ($tip == "izbrisi") {
            $id = trim($request->getParam("id")); //http://restapiserver/RestApi/type/date/id/16
            $requestApi = $this->client->restDelete("/RestApi/type/date/id/" . $id);
            $response = $requestApi->getRawBody();
            $jsonResponse = Zend_Json_Decoder::decode($response);
            if (!empty($jsonResponse)) {
                if ($jsonResponse['success'] == 1) {
                    $this->redirect("/Administrator/datum/tip/pregled");
                } else {
                    $this->view->resultMessage = $jsonResponse['body'];
                }
            }
        } elseif ($tip == "izmeni") {
            $datumRezMapper = new Application_Model_DatumRezervacijaMapper();
            $datumRezervacijeObj = new Application_Model_DatumRezervacija();
            $datumRezMapper->find($request->getParam("id"), $datumRezervacijeObj);

            $form = new Zend_Form();
            $form->setMethod("post");
            $form->setAction("/Administrator/datum/tip/izmeni");
            $form->setName("DatumForm");
            $form->setDescription("Adding new Date");
            $form->setAttrib("class", "DateForm");

            $element = new Zend_Form_Element_Text("tbDateUp");
            $element->setLabel("Birthday Date:");
            $element->setRequired(true);
            $element->addValidator("NotEmpty", true, array("messages" => "Date is mandatory"));
            $element->addValidator(new Zend_Validate_Regex("/^((19|20)\d\d)-(0?[1-9]|1[012])-(0?[1-9]|[12][0-9]|3[01])$/"), true)
                    ->addErrorMessage('Date example YYYY-MM-DD / 2017-01-30.');
            $element->addFilter(new Zend_Filter_HtmlEntities());
            $element->addFilter(new Zend_Filter_StripTags());
            $element->addFilter(new Zend_Filter_StringTrim());
            $element->setValue($datumRezervacijeObj->getDatum_rezervacije());
            //$form->addElement($this->element->getAdminTextElement( array("class", "date")));
            $submitFormElement = new Zend_Form_Element_Submit("btnSubmit");
            $submitFormElement->setLabel("Update");
            $submitFormElement->setAttribs(array("class" => "btnSubmit"));
            $hiddenEl = new Zend_Form_Element_Hidden("hiddenId");
            $hiddenEl->setValue($request->getParam("id"));

            $form->addElement($element);
            $form->addElement($hiddenEl);
            $form->addElement($submitFormElement);

            if ($request->isPost() && $form->isValid($request->getPost())) {
                $date = $request->getPost("tbDateUp");
                $idDatum = $request->getPost("hiddenId");
                $requestApi = $this->client->restPost('/RestApi', array('type' => 'date', 'datum_rezervacije' => $date, 'id_datum' => $idDatum));
                $response = $requestApi->getRawBody();
                $jsonResponse = Zend_Json_Decoder::decode($response);
                print $jsonResponse['success'];

                if ($jsonResponse['success'] == 1) {
                     $this->redirect("/Administrator/datum/tip/pregled");
                } else {
                    $this->view->resultMessage = $jsonResponse['body'];
                }
            } else {
//                $form->addElement($element);
//                $form->addElement($submitFormElement);
//                $form->addElement($hiddenEl);
                $this->view->formDatum = $form;
            }
        } else {
            $links = array(
                array('key' => "/Administrator/datum/tip/unos", 'value' => "Insert Date for reservation"),
                array('key' => "/Administrator/datum/tip/pregled", 'value' => "View, Update or Delete Date for reservation"),
            );

            $this->view->links = $links;
        }
    }

    public function galerijaAction() {
        $this->view->assign("div_class_for_every_page", 'about');
        $request = $this->getRequest();
        if (!$this->ulogovan && $this->session->read()->id_uloga != 1) {
            $this->redirect("/Index");
        }
        $tip = $request->getParam("tip");
        if ($tip == "unos") {
            $form = new Application_Form_MyFormAdminGalerija();

            if ($request->isPost() && $form->isValid($request->getPost())) {
                $galerijaNaziv = $request->getPost('tbGallery');
                $requestApi = $this->client->restPost('/RestApi', array('type' => 'gallery', 'nazivGalerije' => $galerijaNaziv));
                $response = $requestApi->getRawBody();
                $jsonResponse = Zend_Json_Decoder::decode($response);
                print $jsonResponse['success'];

                if ($jsonResponse['success'] == 1) {
                    $this->view->resultMessage = $jsonResponse['body'];
                } else {
                    $this->view->resultMessage = $jsonResponse['body'];
                }
            } else {
                $this->view->formGall = $form;
            }
        } elseif ($tip == "pregled") {

            $requestApi = $this->client->restGet('/RestApi', array('type' => 'gallery'));
            $response = $requestApi->getRawBody();
            $jsonResponse = Zend_Json_Decoder::decode($response);
            if ($jsonResponse['success'] == 1) {
                $this->view->galleryTable = $jsonResponse['body'];
            } else {
                $this->view->galleryTable = $jsonResponse['body'];
            }
        } elseif ($tip == "izbrisi") {
            $id = trim($request->getParam("id"));
            $requestApi = $this->client->restDelete("/RestApi/type/gallery/id/" . $id);
            $response = $requestApi->getRawBody();
            $jsonResponse = Zend_Json_Decoder::decode($response);
            if (!empty($jsonResponse)) {
                if ($jsonResponse['success'] == 1) {
                    $this->redirect("/Administrator/galerija/tip/pregled");
                } else {
                    $this->view->resultMessage = $jsonResponse['body'];
                }
            }
        } elseif ($tip == "izmeni") {
            $id = trim($request->getParam("id"));
            $id_galerija = intval($id);
            $galerija = new Application_Model_Galerija();
            $galerijaMapper = new Application_Model_GalerijaMapper();
            $galerijaMapper->find($id_galerija, $galerija);

            $form = new Application_Form_MyFormAdminGalerija(null, $galerija->getNaziv());
            $hidden = new Zend_Form_Element_Hidden("hiddenId");
            $hidden->setValue($id_galerija);
            $form->addElement($hidden);

            if ($request->isPost() && $form->isValid($request->getPost())) {
                $galerijaNaziv = $request->getPost('tbGallery');
                $id_galerija = $request->getPost("hiddenId");
                $requestApi = $this->client->restPost('/RestApi', array('type' => 'gallery', 'nazivGalerije' => $galerijaNaziv, 'id_galerija' => $id_galerija));
                $response = $requestApi->getRawBody();
                $jsonResponse = Zend_Json_Decoder::decode($response);
                print $jsonResponse['success'];

                if ($jsonResponse['success'] == 1) {
                    $this->redirect("/Administrator/galerija/tip/pregled");
                } else {
                    $this->view->resultMessage = $jsonResponse['body'];
                }
            } else {
                $this->view->formGall = $form;
            }
        } else {
            $links = array(
                array('key' => "/Administrator/galerija/tip/unos", 'value' => "Insert Gallery"),
                array('key' => "/Administrator/galerija/tip/pregled", 'value' => "View, Update or Delete Gallery"),
            );

            $this->view->links = $links;
        }
    }

    public function aktivnostAction() {
        $this->view->assign("div_class_for_every_page", 'about');
        $request = $this->getRequest();
        if (!$this->ulogovan && $this->session->read()->id_uloga != 1) {
            $this->redirect("/Index");
        }
        $tip = $request->getParam("tip");
        if ($tip == "unos") {
            $form = new Application_Form_MyFormAdminAktivnost();
            //echo print_r($request->getPost("tbDate"));
            if ($request->isPost() && $form->isValid($request->getPost())) {
                $naslov = trim(addslashes($request->getPost("tbNaslov")));
                $tekst = trim(addslashes($request->getPost("taTekst")));
                $date = trim(addslashes($request->getPost("tbDate")));
                $termin = trim(addslashes($request->getPost("tbTermin")));
                $mesto = trim(addslashes($request->getPost("tbMesto")));
                $dateForInsert = $this->dateRebuilder($date);
                $requestApi = $this->client->restPost('/RestApi', array(
                    'type' => 'event',
                    'naslov' => $naslov,
                    'tekst' => $tekst,
                    'datum_odrzavanja' => $dateForInsert,
                    'vreme' => $termin,
                    'mesto' => $mesto
                ));
                $response = $requestApi->getRawBody();
                $jsonResponse = Zend_Json_Decoder::decode($response);
                //print $jsonResponse['success'];

                if ($jsonResponse['success'] == 1) {
                    $this->view->resultMessage = $jsonResponse['body'];
                } else {
                    $this->view->resultMessage = $jsonResponse['body'];
                }
            } else {
                $this->view->formEvent = $form;
            }
        } elseif ($tip == "pregled") {

            $requestApi = $this->client->restGet('/RestApi', array('type' => 'event'));
            $response = $requestApi->getRawBody();
            $jsonResponse = Zend_Json_Decoder::decode($response);
            if ($jsonResponse['success'] == 1) {
                $this->view->eventTable = $jsonResponse['body'];
            } else {
                $this->view->eventTable = $jsonResponse['body'];
            }
        } elseif ($tip == "izbrisi") {
            $id = trim($request->getParam("id")); //http://restapiserver/RestApi/type/event/id/8
            $requestApi = $this->client->restDelete("/RestApi/type/event/id/" . $id);
            $response = $requestApi->getRawBody();
            $jsonResponse = Zend_Json_Decoder::decode($response);
            if (!empty($jsonResponse)) {
                if ($jsonResponse['success'] == 1) {
                    $this->redirect("/Administrator/aktivnost/tip/pregled");
                } else {
                    $this->view->resultMessage = $jsonResponse['body'];
                }
            }
        } elseif ($tip == "izmeni") {
            $id = trim($request->getParam("id"));
            $id_aktivnost = intval($id);
            $form = new Zend_Form();
            $form->setMethod("post");
            $form->setAction("/Administrator/aktivnost/tip/izmeni");
            $form->setName("EventForm");
            $form->setDescription("Adding new Event");
            $form->setAttrib("class", "DateForm");

            $aktivnost = new Application_Model_Aktivnost();
            $aktivnostMapper = new Application_Model_AktivnostMapper();
            $aktivnostMapper->find($id_aktivnost, $aktivnost);
            //print_r($aktivnost);
            $naslov = new Zend_Form_Element_Text("tbNaslov");
            $naslov->addValidator("NotEmpty", true, array("messages" => "Header is mandatory"));
            $naslov->addValidator(new Zend_Validate_Regex("/^[A-Z]{1}[A-z - 0-9]{2,60}$/"), true)
                    ->addErrorMessage("Header of event must start with upper letter and cannot start with a number.");
            $naslov->setLabel("Header: ");
            $naslov->setAttrib("class", "galerija");
            $naslov->setValue($aktivnost->getNaslov());

            $textArea = new Zend_Form_Element_Textarea("taTekst");
            $textArea->setLabel("Text: ");
            $textArea->setRequired(true);
            $textArea->addValidator("NotEmpty", true, array("messages" => "Period is mandatory"));
            $textArea->addFilter(new Zend_Filter_HtmlEntities());
            $textArea->addFilter(new Zend_Filter_StripTags());
            $textArea->addFilter(new Zend_Filter_StringTrim());
            $textArea->setValue($aktivnost->getTekst());

            $dateElement = new Zend_Form_Element_Text("tbDate");
            $dateElement->addValidator(new Zend_Validate_Regex("/^(0?[1-9]|1[012])\/(0?[1-9]|[12][0-9]|3[01])\/((19|20)\d\d)$/"), true)
                    ->addErrorMessage("Use date picker for date.");
            $dateElement->setLabel("Date of event:");
            $dateElement->setAttrib("class", "date");
            //$dateElement->setValue($aktivnost->getDatum_odrzavanja());

            $termin = new Zend_Form_Element_Text("tbTermin");
            $termin->addValidator(new Zend_Validate_Regex("/^[0-9]{2}:[0-9]{2} - [0-9]{2}:[0-9]{2}$/"), true)
                    ->addErrorMessage("Period example 09:00 - 12:00.");
            $termin->setLabel("Period example: 12:00 - 15:00");
            //$termin->setAttrib("class", "termin");
            $termin->setValue($aktivnost->getVreme());

            $mesto = new Zend_Form_Element_Text("tbMesto");
            $mesto->addValidator(new Zend_Validate_Regex("/^[A-Z]{1}[A-z0-9 ,-]{2,60}$/"), true)
                    ->addErrorMessage("Place of event must start with upper case and can contain only number letters - and ,.");
            $mesto->setLabel("Place of event: ");
            $mesto->setAttrib("class", "event");
            $mesto->setValue($aktivnost->getMesto());

            $hiddenElement = new Zend_Form_Element_Hidden("hiddenId");
            $hiddenElement->setValue($id_aktivnost);

            $submit = new Zend_Form_Element_Submit("btnSubmit");
            $submit->setLabel("Update");
            $submit->setAttrib("class", "btnSubmit");

            $form->addElement($naslov);
            $form->addElement($textArea);
            $form->addElement($dateElement);
            $form->addElement($termin);
            $form->addElement($mesto);
            $form->addElement($hiddenElement);
            $form->addElement($submit);

            if ($request->isPost() && $form->isValid($request->getPost())) {
                $naslov = trim(addslashes($request->getPost("tbNaslov")));
                $tekst = trim(addslashes($request->getPost("taTekst")));
                $date = trim(addslashes($request->getPost("tbDate")));
                $termin = trim(addslashes($request->getPost("tbTermin")));
                $mesto = trim(addslashes($request->getPost("tbMesto")));
                $idAktivnost = trim(addslashes($request->getPost("hiddenId")));
                $dateForInsert = $this->dateRebuilder($date);
                $requestApi = $this->client->restPost('/RestApi', array(
                    'type' => 'event',
                    'naslov' => $naslov,
                    'tekst' => $tekst,
                    'datum_odrzavanja' => $dateForInsert,
                    'vreme' => $termin,
                    'mesto' => $mesto,
                    'id_aktivnost' => $idAktivnost
                ));
                $response = $requestApi->getRawBody();
                $jsonResponse = Zend_Json_Decoder::decode($response);
                //print $jsonResponse['success'];

                if ($jsonResponse['success'] == 1) {
                    $this->redirect("/Administrator/aktivnost/tip/pregled");
                } else {
                    $this->view->resultMessage = $jsonResponse['body'];
                }
            } else {
                $this->view->formEvent = $form;
            }
        } else {
            $links = array(
                array('key' => "/Administrator/aktivnost/tip/unos", 'value' => "Insert Event"),
                array('key' => "/Administrator/aktivnost/tip/pregled", 'value' => "View, Update or Delete Events"),
            );

            $this->view->links = $links;
        }
    }

    public function slikaAction() {
        $this->view->assign("div_class_for_every_page", 'about');
        $request = $this->getRequest();
        if (!$this->ulogovan && $this->session->read()->id_uloga != 1) {
            $this->redirect("/Index");
        }
        $tip = $request->getParam("tip");

        switch ($tip) {
            case 'unos':
                $galerijaMapper = new Application_Model_GalerijaMapper();
                $galerijeZaDDL = $galerijaMapper->fetchAllForDDL();
                $form = new Application_Form_MyFormAdminSlika($galerijeZaDDL);
                $fileDirectrory = APPLICATION_PATH . '/../public/images/igraonica/';
                if ($request->isPost() && $form->isValid($request->getPost())) {
                    $naziv = $request->getPost('tbNaziv');
                    $id_galerije = $request->getPost("ddlGalerija");
                    $upload = new Zend_File_Transfer_Adapter_Http();
                    $odrediste = $fileDirectrory;
                    if (!file_exists($odrediste)) {
                        mkdir($odrediste);
                    }
                    $upload->setDestination($odrediste . '/');
                    $imeFajla = $upload->getFileName();

                    $ekstenzija1 = explode('.', $imeFajla);
                    $ekstenzija = $ekstenzija1[count($ekstenzija1) - 1];
                    $nazivSlike = $ekstenzija1[count($ekstenzija1) - 2];
                    $novoIme = date('d_M_Y_H_s_i') . '.' . $ekstenzija;
                    $upload->addFilter('Rename', array('target' => $novoIme));
                    $upload->addValidator('Extension', false, array('jpg', 'png', 'gif', 'jpeg'));
                    $upload->setOptions(array('useByteString' => FALSE));
//                    
                    if ($upload->receive()) {
                        $requestApi = $this->client->restPost('/RestApi', array(
                            'type' => 'picture',
                            'putanja' => "images/igraonica/" . $novoIme,
                            'naziv' => $naziv,
                            'id_galerija' => $id_galerije
                        ));
                        $response = $requestApi->getRawBody();
                        $jsonResponse = Zend_Json_Decoder::decode($response);
                        //print $jsonResponse['success'];

                        if ($jsonResponse['success'] == 1) {
                            $this->view->resultMessage = $jsonResponse['body'];
                        } else {
                            $this->view->resultMessage = $jsonResponse['body'];
                        }
                    } else {
                        print "Update failed, please try again.";
                        $this->view->formSlika = $form;
                    }
                } else {
                    $this->view->formSlika = $form;
                }
                break;
            case 'pregled':
                $requestApi = $this->client->restGet('/RestApi', array('type' => 'picture'));
                $response = $requestApi->getRawBody();
                $jsonResponse = Zend_Json_Decoder::decode($response);
                //var_dump($jsonResponse);
                if ($jsonResponse['success'] == 1) {
                    $this->view->slikaTable = $jsonResponse['body'];
                } else {
                    $this->view->slikaTable = $jsonResponse['body'];
                }
                break;
            case 'izbrisi':
                $id = trim($request->getParam("id")); //http://restapiserver/RestApi/type/event/id/8
                $idSlika = intval($id);
                if ($idSlika !== null && $idSlika !== 0 && !empty($idSlika)) {
                    $requestApi = $this->client->restDelete("/RestApi/type/picture/id/" . $idSlika);
                    $response = $requestApi->getRawBody();
                    //print $id;
                    $jsonResponse = Zend_Json_Decoder::decode($response);
                    if (!empty($jsonResponse)) {
                        if ($jsonResponse['success'] == 1) {
                            $this->redirect("/Administrator/slika/tip/pregled");
                        } else {
                            $this->view->resultMessage = $jsonResponse['body'];
                        }
                    }
                }

                break;
            default:
                $links = array(
                    array('key' => "/Administrator/slika/tip/unos", 'value' => "Insert Picture"),
                    array('key' => "/Administrator/slika/tip/pregled", 'value' => "View, Update or Delete Picture"),
                );

                $this->view->links = $links;
                break;
        }
    }

    private function dateRebuilder($date) {
        $tmp = explode("/", $date);
        //print_r($tmp);
        $dateForReturn = $tmp[2] . "-" . $tmp[0] . "-" . $tmp[1];
        return $dateForReturn;
    }

}
