<?php

class LoginController extends Base_FrontEnd {

    public function init() {
        $this->ulogovan();
    }

    public function indexAction() {
        $form = new Application_Form_MyLoginForm();
        $request = $this->getRequest();
        
        if ($request->isPost() && $form->isValid($request->getPost())) {
            // LOGOVANJE
            $korIme = $form->getValue("tbUsername");
            $pass = $form->getValue("tbPassword");

            $auth = Zend_Auth::getInstance();
            $korisnikTabela = new Application_Model_DbTable_Korisnik();
            $authAdapter = new Zend_Auth_Adapter_DbTable($korisnikTabela->getAdapter(), 'korisnik');

            $authAdapter->setIdentityColumn("username")->setCredentialColumn("password");
            $authAdapter->setIdentity($korIme)->setCredential(md5($pass));
            $result = $auth->authenticate($authAdapter);
            
            if ($result->isValid()) {

                $sesija = new Zend_Auth_Storage_Session();
                $data = $authAdapter->getResultRowObject(array('id_korisnik','id_uloga','username','email'), null);
                $sesija->write($data);
               
                if ($data->id_uloga == 1) {
                    $this->redirect('/Administrator');
                } else {
                    $this->redirect('/Index');
                }
            } else {
                $this->_helper->layout()->login = $form;
                $this->_helper->layout()->message = "Credentials are not right, try again!!";
            }
        }
        else
        {
            $this->view->assign('div_class_for_every_page', 'index');
            $this->_helper->layout()->login = $form;
            //$messages=$form->getMessages();
            //$this->_helper->layout()->errors=$messages;
        }
    }

    public function logoutAction() {
        $this->_helper->viewRenderer->setNoRender(true);
        if ($this->ulogovan && $this->getRequest()->isPost()) {
            $sesija = new Zend_Auth_Storage_Session();
            $sesija->clear();
        }
        $this->redirect("/Index");
    }

}
