<?php

class ReservationController extends Base_FrontEnd {

    public function init() {
        $this->ulogovan();
        $this->view->headTitle()->append(" Birthday Reservation");
        $this->view->headScript()->appendFile("/js/my.js");
    }

    public function indexAction() {
        $this->view->assign("div_class_for_every_page", "events");
        $eventsMapper = new Application_Model_AktivnostMapper();
        $topThree = $eventsMapper->fetchTopThree();
        $this->view->topThree = $topThree;

        if (!$this->ulogovan) {
            $form = new Application_Form_MyLoginForm();
            $this->_helper->layout()->login = $form;
        } else {
            $form = new Application_Form_MyFormLogout();
            $this->_helper->layout()->logout = $form;
        }
        $sesija = new Zend_Auth_Storage_Session();       
        $request = $this->getRequest();

        if ($request->isPost()) {
            if (!Zend_Auth::getInstance()->hasIdentity()) {
                $this->_redirect('Index');
            }
            $datumMapper = new Application_Model_DatumRezervacijaMapper();
            $datumi = $datumMapper->fetchDatum();
            $formReservation = new Application_Form_MyFormReservation($datumi);
            $idTermin = $request->getPost("ddlTermin");
            $idDatum = $request->getPost("ddlDatum");

            if ($idTermin != 0 && intval($idTermin) && intval($idDatum) && $idDatum != 0) {
                $formReservation->getTerminElement()->setRegisterInArrayValidator(false);
                $formReservation->getDatumElement()->setRegisterInArrayValidator(false);

                if ($formReservation->isValid($request->getPost())) {

                    $slavljenik = $request->getPost("tbSlavljenik");
                    $email = $request->getPost("tbEmail");
                    $username=$sesija->read()->username; 
                    $rezervacije = new Application_Model_Rezervacije();
                    $rezervacije->setUsername($username)
                            ->setSlavljenik($slavljenik)
                            ->setEmail($email)
                            ->setId_datum($idDatum)
                            ->setId_termin($idTermin);

                    $rezervacijaMapper = new Application_Model_RezervacijeMapper();
                    $rez = $rezervacijaMapper->save($rezervacije);

                    if ($rez != null && !empty($rez) && $rez != 0) {
                        $this->view->reservationResultMessage = "You have successfully made a reservation for " . $slavljenik . " birthday!"
                                . " Hope you have fun. ";
                    } else {
                        $this->view->reservationResultMessage = "Sorry, our server is not running at the moment, please try again later.";
                    }
                } else {
                    $this->view->formReservation = $formReservation;
                }
            } else {
                if (!$formReservation->isValid($request->getPost())) {
                    $this->view->formReservation = $formReservation;
                }
            }
        } else {
            $datumMapper = new Application_Model_DatumRezervacijaMapper();
            $datumi = $datumMapper->fetchDatum();
            $formReservation = new Application_Form_MyFormReservation($datumi);
            $this->view->formReservation = $formReservation;
        }
    }

    public function ajaxAction() {
        $this->_helper->layout()->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
        $request = $this->getRequest();
        $idDatum = $request->getParam("dataId");
        if (!empty($idDatum) && $idDatum != null) {
            
            $rezervacijaMapper = new Application_Model_RezervacijeMapper();
            $termin = new Application_Model_Termin();
            $rezervacijeAkoPostojeZaOdredjeniDatum = $rezervacijaMapper->findDatum($idDatum, $termin);
            $idTerminaKojiNetrebaju = [];
            //var_dump($rezervacijeAkoPostojeZaOdredjeniDatum);
            if ($rezervacijeAkoPostojeZaOdredjeniDatum != null) {
                for ($i = 0; $i < count($rezervacijeAkoPostojeZaOdredjeniDatum); $i++) {
                    $idTerminaKojiNetrebaju[$i] = $rezervacijeAkoPostojeZaOdredjeniDatum[$i]->id_termin;
                    //var_dump($idTerminaKojiNetrebaju[$i]);
                }
            }
            $terminiMapper = new Application_Model_TerminMapper();
            $terminiZaOutput = $terminiMapper->fetchTermin($idTerminaKojiNetrebaju);
            echo json_encode($terminiZaOutput);
        }
    }

}
