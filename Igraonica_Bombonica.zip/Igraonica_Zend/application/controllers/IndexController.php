<?php

class IndexController extends Base_FrontEnd {

    public function init() {
        $this->ulogovan();
    }

    public function indexAction() {
        $this->view->assign('div_class_for_every_page', 'index');
        if (!$this->ulogovan) {
            $form = new Application_Form_MyLoginForm();
            $this->_helper->layout()->login = $form;
        } else {
            $form = new Application_Form_MyFormLogout();
            $this->_helper->layout()->logout = $form;
        }
    }

}
