<?php

class GalleryController extends Base_FrontEnd
{

    public function init()
    {
        $this->view->headTitle()->append(" Gallery");
        $this->ulogovan();
    }

    public function indexAction()
    {
        $this->view->assign("div_class_for_every_page","gallery");
        if (!$this->ulogovan) {
           $form = new Application_Form_MyLoginForm();
           $this->_helper->layout()->login = $form; 
        } else {
           $form = new Application_Form_MyFormLogout();
           $this->_helper->layout()->logout = $form; 
        }   
        $slike = new Application_Model_SlikaGalerijaMapper();
        $sveSlike = $slike->fetchAll();
        $this->view->sveSlike=$sveSlike;
    }


}

