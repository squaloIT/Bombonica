<?php

class RegisterController extends Base_FrontEnd {

    public function init() {
        $this->view->headTitle()->append(" Register");
        $this->ulogovan();
    }

    public function indexAction() {
        $this->view->assign("div_class_for_every_page", "events");
        $request = $this->getRequest();
        $form = new Application_Form_MyFormRegister();
        if ($request->isPost() && $form->isValid($request->getPost())) {

            $username = $request->getPost("tbUsername");
            $password = $request->getPost("tbPassword");
            //$passwordConfirm=$request->getPost("tbPasswordConfirm");
            $email = $request->getPost("tbEmail");
            $phone = $request->getPost("tbPhone");
            $address = $request->getPost("tbAddress");
            $korisnik = new Application_Model_Korisnik();
            $korMapper = new Application_Model_KorisnikMapper();
            $korisnik->setUsername(trim(addslashes($username)));
            $korisnik->setPassword(md5(trim(addslashes($password))));
            $korisnik->setEmail(trim(addslashes($email)));
            $korisnik->setPhoneNumber(trim(addslashes($phone)));
            $korisnik->setAddress(trim(addslashes($address)));

            $registrationResult = $korMapper->save($korisnik);

            if ($registrationResult != null && !empty($registrationResult) && $registrationResult != 0) {
                $this->view->registrationResultMessage = "You have successfully registered!"
                        . " Hope you have fun. ";
            } else {
                $this->view->registrationResultMessage = "Sorry, our server is not running at the moment, please try again later.";
            }
            //TODO Ako ovo sejvuje onda mu se salje mail sa linkom koji ce da promeni status      
        } else {
            
            $this->view->form = $form;
            $this->_helper->layout()->flag = true;
        }
    }

}
