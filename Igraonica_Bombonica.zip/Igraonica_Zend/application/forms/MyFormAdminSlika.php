<?php

class Application_Form_MyFormAdminSlika extends Zend_Form {

    private $element;
    public function init()
    {
        include dirname(__DIR__)."/forms/MyFormElements.php";
        $this->element = new MyFormElements();
    }

    public function __construct($ddl=null,$options = null) {
        parent::__construct($options);

        $this->setMethod("post");
        $this->setAttrib('enctype', 'multipart/form-data');
        $this->setAction("/Administrator/slika/tip/unos");
        $this->setName("SlikaForm");
        $this->setDescription("Adding new picture");
        // $this->setAttrib("class", "pictureForm");
        $element = new Zend_Form_Element_File('filePicture');
        $element->setLabel('Upload an image:');
                //->setDestination(APPLICATION_PATH .'/../public/images/igraonica');//C:\xampp\htdocs\Igraonica_Zend\public\images\igraonica
// ensure minimum 1, maximum 3 files
        $element->addValidator('Count', false, 1);
// limit to 100K
        $element->addValidator('Size', false, 10240000);
// only JPEG, PNG, and GIFs
        $element->addValidator('Extension', false, 'jpg,png,gif');
        $this->addElement($this->element->getAdminTextElement("tbNaziv", "/^[\w ,-_]+$/", 'How did you get this wrong!?.', "Pictures alt tag: ", array("class", "Alt")));
        $this->addElement($element);
        $this->addElement($this->element->getDatumElement(
                "ddlGalerija", 
                $ddl, 
                "Galerija is mandatory.",
                "Gallery for picture: ", 
                array("class"=>"galerija"))
                );
        $this->addElement($this->element->getSubmitElement("Insert", array("class" => "btnSubmit")));
    }

}
