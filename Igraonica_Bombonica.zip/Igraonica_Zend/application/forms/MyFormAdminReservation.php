<?php

class Application_Form_MyFormAdminReservation extends Zend_Form {

    private $element;
    private $terminElement;
    private $datumElement;

    public function init() {
        include dirname(__DIR__) . "/forms/MyFormElements.php";
        $this->element = new MyFormElements();
    }

    public function __construct($ddlDatum = [], $options = null, $value = null) {
        parent::__construct($options);

        if (empty($value)) {
            $this->setMethod("post");
            $this->setAction("/Administrator/rezervacije/tip/unos");
            $this->setName("ReservationForm");
            $this->setDescription("Forma za rezervacije");
            $this->setAttrib("class", "rezervacija");

            $this->datumElement = $this->element->getDatumElement("ddlDatum", $ddlDatum, "Date of birthday is mandatory", "Date of Birthday: ", array("class" => "datumChange"));
            $this->terminElement = $this->element->getTerminElement("ddlTermin", "Time of birthday is mandatory", "Time: ", array("class" => "termin"));

            $this->addElement($this->element->getSlavljenikElement());
            $this->addElement($this->element->getEmailElement());
            $this->addElement($this->element->getUsernameElement());
            $this->addElement($this->getDatumElement());
            $this->addElement($this->getTerminElement());
            $this->addElement($this->element->getSubmitElement("Insert"));
        } else {
            $this->setMethod("post");
            $this->setAction("/Administrator/rezervacije/tip/izmeni");
            $this->setName("ReservationForm");
            $this->setDescription("Forma za rezervacije");
            $this->setAttrib("class", "rezervacija");

            $this->datumElement = $this->element->getDatumElement("ddlDatum", $ddlDatum, "Date of birthday is mandatory", "Date of Birthday: ", array("class" => "datumChange"));
            $this->terminElement = $this->element->getTerminElement("ddlTermin", "Time of birthday is mandatory", "Time: ", array("class" => "termin"));
            
            $slavljenik =$this->element->getSlavljenikElement();
            $slavljenik->setValue($value['slavljenik']);
            $email=$this->element->getEmailElement();
            $email->setValue($value['email']);
            $username=$this->element->getUsernameElement();
            $username->setValue($value['username']);
            $hidden = new Zend_Form_Element_Hidden("hiddenId");
            $hidden->setValue($value['id_rezervacije']);
            
            $this->addElement($slavljenik);
            $this->addElement($email);
            $this->addElement($username);
            $this->addElement($this->getDatumElement());
            $this->addElement($this->getTerminElement());
            $this->addElement($hidden);
            $this->addElement($this->element->getSubmitElement("Update"));
        }
    }

    public function getTerminElement() {
        return $this->terminElement;
    }

    public function getDatumElement() {
        return $this->datumElement;
    }

}
