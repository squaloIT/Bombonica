<?php

class MyFormElements {

    public function getEmailElement($nameOfElement = "tbEmail", $attribs = array()) {
        $emailFormElement = new Zend_Form_Element_Text($nameOfElement);
        $emailFormElement->setLabel("Email: ");
        $emailFormElement->addValidator("NotEmpty", true, array("messages" => "Password is mandatory"));
        $emailFormElement->addValidator(new Zend_Validate_EmailAddress(), false, array('messages' => 'ERROR: Email must be in valid format! '));
        $emailFormElement->setRequired(true);
        $emailFormElement->setAttribs($attribs);
        $emailFormElement->addFilters(array(new Zend_Filter_HtmlEntities(), new Zend_Filter_StripTags(), new Zend_Filter_StringTrim()));

        return $emailFormElement;
    }

    public function getUsernameElement($nameOfElement = "tbUsername") {
        $usernameFormElement = new Zend_Form_Element_Text($nameOfElement);
        $usernameFormElement->setLabel("Username: ");
        $usernameFormElement->setAttrib("class", "myform username");
        $usernameFormElement->setRequired(true);
        $usernameFormElement->addValidator("NotEmpty", true, array("messages" => "Username is mandatory"));
        $usernameFormElement->addValidator("StringLength", true, array(3, 30))->addErrorMessage('Username Cannot be more than 20 or less than 5 chars');
        $usernameFormElement->addValidator("Alnum", true)->addErrorMessage('Username can cointain only alphanumeric characters');

        $usernameFormElement->addFilters(
                array(new Zend_Filter_HtmlEntities(), new Zend_Filter_StripTags(), new Zend_Filter_StringTrim()));

        return $usernameFormElement;
    }

    public function getPasswordElement($nameOfElement = "TbPassword") {

        $passwordElement = new Zend_Form_Element_Password($nameOfElement);
        $passwordElement->setLabel('Password:');
        $passwordElement->setRequired(true);
        $passwordElement->addValidator("NotEmpty", true, array("messages" => "Password is mandatory"));
        $passwordElement->setAttrib("class", "myform password");
        $passwordElement->addValidator('StringLength', true, array(3, 30, 'messages' => ' Password cannot be more than 30 or less than 3 chars'));
        $passwordElement->addFilter(new Zend_Filter_HtmlEntities());
        $passwordElement->addFilter(new Zend_Filter_StripTags());
        $passwordElement->addFilter(new Zend_Filter_StringTrim());
        return $passwordElement;
    }

    public function getPhoneNumberElement($nameOfElement = "TbPhoneNumber", $attribs = array()) {
        $phoneNumberElement = new Zend_Form_Element_Text($nameOfElement);
        $phoneNumberElement->setLabel('Phone number:');
        $phoneNumberElement->setRequired(true);
        $phoneNumberElement->addValidator('NotEmpty', true, array('messages' => ' Phone number is mandatory'));
        $phoneNumberElement->addValidator(new Zend_Validate_Regex("/^[0-9+\-\.\/\(\) ]{6,30}$/"), true)->addErrorMessage('Phone number must be in format 0669161111');
        $phoneNumberElement->setAttribs($attribs);
        $phoneNumberElement->addFilter(new Zend_Filter_HtmlEntities());
        $phoneNumberElement->addFilter(new Zend_Filter_StripTags());
        $phoneNumberElement->addFilter(new Zend_Filter_StringTrim());
        return $phoneNumberElement;
    }

    public function getAddressElement($nameOfElement = "TbPhoneNumber", $attribs = array()) {
        $addressElement = new Zend_Form_Element_Text($nameOfElement);
        $addressElement->setLabel("Address");
        $addressElement->setRequired(true);
        $addressElement->addValidator("NotEmpty", true, array("messages" => "Address is mandatory"));
        $addressElement->addValidator(new Zend_Validate_Regex("/^[A-Z]{1}[A-z0-9 ]{5,80}$/"), true)->addErrorMessage('Address example Vojvode Supljikca 12');
        $addressElement->setAttribs($attribs);
        $addressElement->addFilter(new Zend_Filter_HtmlEntities());
        $addressElement->addFilter(new Zend_Filter_StripTags());
        $addressElement->addFilter(new Zend_Filter_StringTrim());
        return $addressElement;
    }

    public function getSlavljenikElement($nameOfElement = "tbSlavljenik", $attribs = array()) {
        $element = new Zend_Form_Element_Text($nameOfElement);
        $element->setLabel("Name of birthday boy/girl");
        $element->setRequired(true);
        $element->addValidator("NotEmpty", true, array("messages" => "Name is mandatory"));
        $element->addValidator(new Zend_Validate_Regex("/^[A-Z]{1}[a-z ]{2,30}$/"), true)
                ->addErrorMessage('Name must begin with an upper letter.');
        $element->setAttribs($attribs);
        $element->addFilter(new Zend_Filter_HtmlEntities());
        $element->addFilter(new Zend_Filter_StripTags());
        $element->addFilter(new Zend_Filter_StringTrim());
        return $element;
    }

    public function getDatumElement($nameOfElement = "", $options = [],$errorMessage="", $label="", $attribs = array()) {
        $element = new Zend_Form_Element_Select($nameOfElement);
        
        $element->addMultiOption(0, "Choose");
        $element->addMultiOptions($options);
        $element->addErrorMessage($errorMessage);
        $element->setLabel($label);
        $element->setRequired(true);
        $element->setAttribs($attribs);
        return $element;
    }
    public function getTerminElement($nameOfElement = "",$errorMessage="", $label="", $attribs = array()) {
        $element = new Zend_Form_Element_Select($nameOfElement);
        $element->setLabel($label);
        $element->setAttribs($attribs);
        return $element;
    }
    public function getUlogaTextElement($nameOfElement = "", $label="",$attribs=array()){
        $element = new Zend_Form_Element_Text($nameOfElement);
        $element->setLabel($label);
        $element->setRequired(true);
        $element->addValidator("NotEmpty", true, array("messages" => "Role name is mandatory"));
        $element->addValidator(new Zend_Validate_Regex("/^[A-Z]{1}[A-z ]{2,20}$/"), true)
                ->addErrorMessage('Role name must begin with an upper letter.');
        $element->setAttribs($attribs);
        $element->addFilter(new Zend_Filter_HtmlEntities());
        $element->addFilter(new Zend_Filter_StripTags());
        $element->addFilter(new Zend_Filter_StringTrim());
        return $element;
    }
    public function getAdminTextElement($nameOfElement = "",$regex="",$errorMessage="", $label="",$attribs=array()) {
        $element = new Zend_Form_Element_Text($nameOfElement);
        $element->setLabel($label);
        $element->setRequired(true);
        $element->addValidator("NotEmpty", true, array("messages" => "Period is mandatory"));
        $element->addValidator(new Zend_Validate_Regex($regex), true)
                ->addErrorMessage($errorMessage);
        //$element->setAttrib($attribs);
        $element->addFilter(new Zend_Filter_HtmlEntities());
        $element->addFilter(new Zend_Filter_StripTags());
        $element->addFilter(new Zend_Filter_StringTrim());
        return $element;
    }
    public function getSubmitElement($labelForSubmit = "Submit", $attribs = array()) {
        $submitFormElement = new Zend_Form_Element_Submit("btnSubmit");
        $submitFormElement->setLabel($labelForSubmit);
        $submitFormElement->setAttribs($attribs);
        return $submitFormElement;
    }

}
