<?php

class Application_Form_MyFormAdminAktivnost extends Zend_Form {

    private $element;

    public function init() {
        include dirname(__DIR__) . "/forms/MyFormElements.php";
        $this->element = new MyFormElements();
    }

    public function __construct($options = null) {
        parent::__construct($options);

        $this->setMethod("post");
        $this->setAction("/Administrator/aktivnost/tip/unos");
        $this->setName("EventForm");
        $this->setDescription("Adding new Event");
        $this->setAttrib("class", "DateForm");

        $this->addElement($this->element->getAdminTextElement("tbNaslov", "/^[A-Z]{1}[A-z - 0-9]{2,60}$/", 'Header of event must start with upper letter and cannot start with a number.', "Header:", array("class", "galerija")));
        $textArea = new Zend_Form_Element_Textarea("taTekst");
        $textArea->setLabel("Text: ");
        $textArea->setRequired(true);
        $textArea->addValidator("NotEmpty", true, array("messages" => "Period is mandatory"));
        $textArea->addFilter(new Zend_Filter_HtmlEntities());
        $textArea->addFilter(new Zend_Filter_StripTags());
        $textArea->addFilter(new Zend_Filter_StringTrim());
        $this->addElement($textArea);
        $this->addElement($this->element->getAdminTextElement("tbDate", 
                "/^(0?[1-9]|1[012])\/(0?[1-9]|[12][0-9]|3[01])\/((19|20)\d\d)$/", 
                'Date example YYYY-MM-DD / 2017-01-30.', 
                "Date of event:", array("class", "date")));
        $this->addElement($this->element->getAdminTextElement("tbTermin", 
                "/^[0-9]{2}:[0-9]{2} - [0-9]{2}:[0-9]{2}$/",
                'Period example 09:00 - 12:00.',
                "Period",
                array("class","termin")));
         $this->addElement($this->element->getAdminTextElement("tbMesto", 
                "/^[A-Z]{1}[A-z0-9 ,-]{2,60}$/",
                'Place of event must start with upper case and can contain only number letters - and ,.',
                "Place of event",
                array("class","event")));
        $this->addElement($this->element->getSubmitElement("Insert", array("class" => "btnSubmit")));
    }

}
