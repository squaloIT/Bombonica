<?php

class Application_Form_MyFormRegister extends Zend_Form {

    public function init() {
        /* Form Elements & Other Definitions Here ... */
    }

    public function __construct($options = null) {
        parent::__construct($options);

        include dirname(__DIR__) . "/forms/MyFormElements.php";
        $elementi = new MyFormElements();
        
        $this->setMethod("post");
        $this->setAction("/Register");
        $this->setDescription("Forma za registraciju korisnika");
        $this->setName("RegisterForm");
        $this->setAttrib("class", "registracija");
        $this->addElement($elementi->getUsernameElement("tbUsername"));
        $this->addElement($elementi->getPasswordElement("tbPassword"));
        $frmPassword2=new Zend_Form_Element_Password('tbPasswordConfirm');
        $frmPassword2->setLabel('Confirm password')
                ->setRequired('true')
                ->setAttrib("class","myform confPassword")
                ->addFilter(new Zend_Filter_StringTrim());
        $frmPassword2->addValidator(new Zend_Validate_Identical('tbPassword'))->addErrorMessage("Passwords do not match");
        $this->addElement($frmPassword2);
        $this->addElement($elementi->getEmailElement("tbEmail",array("class"=>"myform email")));
        $this->addElement($elementi->getPhoneNumberElement("tbPhone",array("class"=>"myform phoneNumber")));
        $this->addElement($elementi->getAddressElement("tbAddress",array("class"=>"myform address")));
        $this->addElement($elementi->getSubmitElement("Register",array("class"=>"btn white")));
    }

}
