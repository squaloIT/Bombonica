<?php

class Application_Form_MyFormAdminTermin extends Zend_Form
{

    private $element;
    public function init()
    {
        include dirname(__DIR__)."/forms/MyFormElements.php";
        $this->element = new MyFormElements();
    }
    public function __construct($options = null) {
        parent::__construct($options);
        
        $this->setMethod("post");
        $this->setAction("/Administrator/termin/tip/unos");
        $this->setName("TerminForm");
        $this->setDescription("Adding new period");
        $this->setAttrib("class", "periodForm");
        
        $this->addElement($this->element->getAdminTextElement("tbTermin", 
                "/^[0-9]{2}:[0-9]{2} - [0-9]{2}:[0-9]{2}$/",
                'Period example 09:00 - 12:00.',
                "Period",
                array("class","termin")));
        $this->addElement($this->element->getSubmitElement("Insert", array("class"=>"btnSubmit")));
        
    }

}

