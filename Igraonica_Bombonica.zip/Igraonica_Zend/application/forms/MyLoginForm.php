<?php

class Application_Form_MyLoginForm extends Zend_Form
{
    public function init()
    {
        //Zend_Loader_Autoloader::autoload("");
      
    }
    
    public function __construct($options = null) {
        
        parent::__construct($options);
        include dirname(__DIR__)."/forms/MyFormElements.php";
        $elementi = new MyFormElements();
        $this->setMethod("post");
        $this->setAction("/Login");
        $this->setName("LoginForm");
        $this->setDescription("Form for login");
        $this->setAttrib("class","form-newsletter");
        
        $this->addElement($elementi->getUsernameElement("tbUsername"));
        $this->addElement($elementi->getPasswordElement("tbPassword"));
        $this->addElement($elementi->getSubmitElement("Login",array("class"=>"btn white")));
        
    }

}

