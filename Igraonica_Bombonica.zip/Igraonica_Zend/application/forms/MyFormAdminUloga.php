<?php

class Application_Form_MyFormAdminUloga extends Zend_Form {

    private $element;
  
    public function init() {
        include dirname(__DIR__) . "/forms/MyFormElements.php";
        $this->element = new MyFormElements();
    }

    public function __construct($options = null, $value=null) {
        parent::__construct($options);
        if ($value === null) {
            $this->setMethod("post");
            $this->setAction("/Administrator/uloga/tip/unos");
            $this->setName("UlogaForm");
            $this->setDescription("Adding new role");
            $this->setAttrib("class", "roles");

            $this->addElement($this->element->getUlogaTextElement("tbUloga", "Role name", array("class" => "uloga")));
            $this->addElement($this->element->getSubmitElement("Insert", array("class" => "btnSubmit")));
        }
        else
        {
            $this->setMethod("post");
            $this->setAction("/Administrator/uloga/tip/izmeni");
            $this->setName("UlogaForm");
            $this->setDescription("Adding new role");
            $this->setAttrib("class", "roles");
            $uloga =$this->element->getUlogaTextElement("tbUloga", "Role name", array("class" => "uloga"));
            $uloga->setValue($value);
            $this->addElement($uloga);
            $this->addElement($this->element->getSubmitElement("Insert", array("class" => "btnSubmit")));
        }
    }

}
