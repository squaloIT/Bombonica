<?php

class Application_Form_MyFormAdminDatum extends Zend_Form
{

    private $element;
    public function init()
    {
        include dirname(__DIR__)."/forms/MyFormElements.php";
        $this->element = new MyFormElements();
    }
    public function __construct($options = null) {
        parent::__construct($options);
        
        $this->setMethod("post");
        $this->setAction("/Administrator/datum/tip/unos");
        $this->setName("DatumForm");
        $this->setDescription("Adding new Date");
        $this->setAttrib("class", "DateForm");
        
        $this->addElement($this->element->getAdminTextElement("tbDate", 
                "/^((19|20)\d\d)\/(0?[1-9]|1[012])\/(0?[1-9]|[12][0-9]|3[01])$/",
                'Use Date picker for date.',
                "Birthday Date:",
                array("class","date")));
        $this->addElement($this->element->getSubmitElement("Insert", array("class"=>"btnSubmit")));
        
    }

}

