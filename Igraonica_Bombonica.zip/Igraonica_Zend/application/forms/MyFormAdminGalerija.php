<?php

class Application_Form_MyFormAdminGalerija extends Zend_Form {

    private $element;

    public function init() {
        include dirname(__DIR__) . "/forms/MyFormElements.php";
        $this->element = new MyFormElements();
    }

    public function __construct($options = null, $value = null) {
        parent::__construct($options);
        if ($value === null) {
            $this->setMethod("post");
            $this->setAction("/Administrator/galerija/tip/unos");
            $this->setName("GalleryForm");
            $this->setDescription("Adding new Gallery");
            $this->setAttrib("class", "GalleryForm");

            $this->addElement($this->element->getAdminTextElement("tbGallery", "/^[A-Z]{1}[A-z ]{2,20}$/", 'Gallery name must start with upper letter and cannot be a number.', "Gallery name:", array("class", "galerija")));
            $this->addElement($this->element->getSubmitElement("Insert", array("class" => "btnSubmit")));
        }
        else
        {
            $this->setMethod("post");
            $this->setAction("/Administrator/galerija/tip/izmeni");
            $this->setName("GalleryForm");
            $this->setDescription("Adding new Gallery");
            $this->setAttrib("class", "GalleryForm");
            $galerijaNaziv=$this->element->getAdminTextElement("tbGallery", "/^[A-Z]{1}[A-z ]{2,20}$/", 'Gallery name must start with upper letter and cannot be a number.', "Gallery name:", array("class", "galerija"));
            $galerijaNaziv->setValue($value);
            $this->addElement($galerijaNaziv);
            $this->addElement($this->element->getSubmitElement("Update", array("class" => "btnSubmit")));
        
        }
    }

}
