<?php

class Application_Form_MyFormReservation extends Zend_Form
{
    private $element;
    private $terminElement;
    private $datumElement;
    
    public function init()
    {
       $this->element = new MyFormElements();
    }
    public function __construct($ddlDatum=[],$options = null) {
        parent::__construct($options);
        
        $this->setMethod("post");
        $this->setAction("/Reservation");
        $this->setName("ReservationForm");
        $this->setDescription("Forma za rezervacije");
        $this->setAttrib("class", "rezervacija");
        
        $this->datumElement=$this->element->getDatumElement("ddlDatum",$ddlDatum,"Date of birthday is mandatory","Date of Birthday: ",array("class"=>"datumChange"));
        $this->terminElement=$this->element->getTerminElement("ddlTermin","Time of birthday is mandatory","Time: ",array("class"=>"termin"));
        
        $this->addElement($this->element->getSlavljenikElement("tbSlavljenik", array("class"=>"form-newsletter")));
        $this->addElement($this->element->getEmailElement());
        $this->addElement($this->getDatumElement());     
        $this->addElement($this->getTerminElement());        
        $this->addElement($this->element->getSubmitElement("btnReservisi"));
        
    }
    public function getTerminElement() {
        return $this->terminElement;
    }

    public function getDatumElement() {
        return $this->datumElement;
    }




}

