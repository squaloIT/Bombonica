<?php

class Application_Form_MyFormLogout extends Zend_Form {

    public function init() {
        /* Form Elements & Other Definitions Here ... */
    }

    public function __construct($options = null) {
        parent::__construct($options);
        include dirname(__DIR__) . "/forms/MyFormElements.php";
        $elementi = new MyFormElements();
        $this->setMethod("post");
        $this->setAction("/Login/logout");
        $this->setName("LogoutForm");
        $this->setDescription("Form for logout");
        $this->setAttrib("class", "form-newsletter");
        
        $this->addElement($elementi->getSubmitElement("Logout",array("class"=>"btn white")));
        
    }

}
