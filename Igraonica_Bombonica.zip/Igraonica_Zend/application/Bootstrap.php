<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap {

    protected function _initDoctype() {
        $this->bootstrap('view');
        $view = $this->getResource('view');
        $view->doctype('HTML5');
    }

    protected function _initPlaceholders() {
       // $this->bootstrap('view');
        $view = $this->getResource('view');
        $view->headTitle("Igraonica Bombonica ")->setSeparator("|");
        $view->headLink()->appendStylesheet("/css/style.css");
        $view->headScript()->appendFile("/js/jquery.bxslider.min.js");
        $view->headScript()->appendFile("/js/jquery.placeholder.js");
        $view->headScript()->appendFile("/js/main.js");
        $view->headScript()->appendFile("https://code.jquery.com/ui/1.12.1/jquery-ui.js");
    }
    protected function _initAutoloader()
    {
        $autoloader = Zend_Loader_Autoloader::getInstance();
        $autoloader->registerNamespace("Base_"); // or Example_
    }

}
