<?php

class Application_Model_Uloga
{
    public $id_uloga;
    public $naziv;
    
    public function getId_uloga() {
        return $this->id_uloga;
    }

    public function getNaziv() {
        return $this->naziv;
    }

    public function setId_uloga($id_uloga) {
        $this->id_uloga = $id_uloga;
        return $this;
    }

    public function setNaziv($naziv) {
        $this->naziv = $naziv;
        return $this;
    }



}

