<?php

class Application_Model_DbTable_Uloga extends Zend_Db_Table_Abstract
{
    protected $_name = 'uloga';
    protected $_primary = 'id_uloga';
    protected $_dependentTables=array('korisnik');
}

