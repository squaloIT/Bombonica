<?php

class Application_Model_DbTable_Korisnik extends Zend_Db_Table_Abstract {

    protected $_name = 'korisnik';
    protected $_primary = 'id_korisnik';
    protected $_referenceMap = array(
        'uloga' => array(
            'columns' => array('id_uloga'),
            'refTableClass' => 'Uloga',
            'refColumns' => array('id_uloga')
        ),
    );

}
