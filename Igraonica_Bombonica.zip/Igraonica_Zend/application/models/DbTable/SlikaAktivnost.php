<?php

class Application_Model_DbTable_SlikaAktivnost extends Zend_Db_Table_Abstract
{

    protected $_name = 'slike_aktivnost';
    protected $_primary = 'id_slika';
    protected $_referenceMap = array(
        'aktivnosti' => array(
            'columns' => array('id_aktivnost'),
            'refTableClass' => 'Aktivnost',
            'refColumns' => array('id_aktivnost')
        ),
    );

}

