<?php

class Application_Model_DbTable_Termin extends Zend_Db_Table_Abstract
{
    protected $_name = 'termini';
    protected $_primary='id_termin';
    protected $_dependentTables=array('rezervacije');
}

