<?php

class Application_Model_DbTable_Aktivnost extends Zend_Db_Table_Abstract
{

    protected $_name = 'aktivnosti';
    protected $_primary ='id_aktivnost';
    protected $_dependentTables=array('slike_aktivnost'); //Moguca greska zbog imena tabele

}

