<?php

class Application_Model_DbTable_Rezervacije extends Zend_Db_Table_Abstract
{
    protected $_name = 'rezervacije';
    protected $_primary='id_rezervacija';
    protected $_referenceMap = array(
        'termini' => array(
            'columns' => array('id_termin'),
            'refTableClass' => 'Termin',
            'refColumns' => array('id_termin')
        ),
        'datum_rezervacija' => array(
            'columns' => array('id_datum'),
            'refTableClass' => 'DatumRezervacija',
            'refColumns' => array('id_datum')
        ),
    );

}

