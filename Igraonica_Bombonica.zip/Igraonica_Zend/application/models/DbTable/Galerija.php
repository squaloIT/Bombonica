<?php

class Application_Model_DbTable_Galerija extends Zend_Db_Table_Abstract
{

    protected $_name = 'galerija';
    protected $_primary='id_galerija';
    protected $_dependentTables=array('slike_galerija');

}

