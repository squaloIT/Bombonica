<?php

class Application_Model_DbTable_DatumRezervacija extends Zend_Db_Table_Abstract
{
    protected $_name = 'datum_rezervacija';
    protected $_primary='id_datum';
    protected $_dependentTables=array('rezervacije');

}

