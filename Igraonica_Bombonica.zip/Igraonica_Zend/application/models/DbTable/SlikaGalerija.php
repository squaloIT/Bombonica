<?php

class Application_Model_DbTable_SlikaGalerija extends Zend_Db_Table_Abstract
{

    protected $_name = 'slike_galerija';
    protected $_primary = 'id_slika';
    protected $_referenceMap = array(
        'galerija' => array(
            'columns' => array('id_galerija'),
            'refTableClass' => 'Galerija',
            'refColumns' => array('id_galerija')
        ),
    );

}

