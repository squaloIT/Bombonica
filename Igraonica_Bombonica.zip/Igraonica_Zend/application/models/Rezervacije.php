<?php

class Application_Model_Rezervacije
{
    protected $id_rezervacija;
    protected $username;
    protected $email;
    protected $slavljenik;
    protected $id_termin;
    protected $id_datum;
    
    public function getId_rezervacija() {
        return $this->id_rezervacija;
    }

    public function getUsername() {
        return $this->username;
    }

    public function getEmail() {
        return $this->email;
    }

    public function getSlavljenik() {
        return $this->slavljenik;
    }

    public function getId_termin() {
        return $this->id_termin;
    }

    public function getId_datum() {
        return $this->id_datum;
    }

    public function setId_rezervacija($id_rezervacija) {
        $this->id_rezervacija = $id_rezervacija;
        return $this;
    }

    public function setUsername($username) {
        $this->username = $username;
        return $this;
    }

    public function setEmail($email) {
        $this->email = $email;
        return $this;
    }

    public function setSlavljenik($slavljenik) {
        $this->slavljenik = $slavljenik;
        return $this;
    }

    public function setId_termin($id_termin) {
        $this->id_termin = $id_termin;
        return $this;
    }

    public function setId_datum($id_datum) {
        $this->id_datum = $id_datum;
        return $this;
    }



}

