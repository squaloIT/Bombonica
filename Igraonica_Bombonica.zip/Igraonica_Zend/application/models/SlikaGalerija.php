<?php

class Application_Model_SlikaGalerija
{
    private $id_slika;
    public $putanja;
    public $naziv;
    public $galerija;
    private $id_galerija;
    
    public function getGalerija() {
        return $this->galerija;
    }

    public function setGalerija($galerija) {
        $this->galerija = $galerija;
        return $this;
    }

        public function getId_slika() {
        return $this->id_slika;
    }

    public function getPutanja() {
        return $this->putanja;
    }

    public function getNaziv() {
        return $this->naziv;
    }

    public function getId_galerija() {
        return $this->id_galerija;
    }

    public function setId_slika($id_slika) {
        $this->id_slika = $id_slika;
        return $this;
    }

    public function setPutanja($putanja) {
        $this->putanja = $putanja;
        return $this;
    }

    public function setNaziv($naziv) {
        $this->naziv = $naziv;
        return $this;
    }

    public function setId_galerija($id_galerija) {
        $this->id_galerija = $id_galerija;
        return $this;
    }



}

