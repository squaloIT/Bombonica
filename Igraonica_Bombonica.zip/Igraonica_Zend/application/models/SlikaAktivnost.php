<?php

class Application_Model_SlikaAktivnost
{
    private $id_slika;
    private $putanja;
    private $naziv;
    private $id_aktivnost;
    
    public function getId_slika() {
        return $this->id_slika;
    }

    public function getPutanja() {
        return $this->putanja;
    }

    public function getNaziv() {
        return $this->naziv;
    }

    public function getId_aktivnost() {
        return $this->id_aktivnost;
    }

    public function setId_slika($id_slika) {
        $this->id_slika = $id_slika;
        return $this;
    }

    public function setPutanja($putanja) {
        $this->putanja = $putanja;
        return $this;
    }

    public function setNaziv($naziv) {
        $this->naziv = $naziv;
        return $this;
    }

    public function setId_aktivnost($id_aktivnost) {
        $this->id_aktivnost = $id_aktivnost;
        return $this;
    }



}

