<?php

class Application_Model_DatumRezervacija
{
    protected $id_datum;
    protected $datum_rezervacije;
    
    public function getId_datum() {
        return $this->id_datum;
    }

    public function getDatum_rezervacije() {
        return $this->datum_rezervacije;
    }

    public function setId_datum($id_datum) {
        $this->id_datum = $id_datum;
        return $this;
    }

    public function setDatum_rezervacije($datum_rezervacije) {
        $this->datum_rezervacije = $datum_rezervacije;
        return $this;
    }
}

