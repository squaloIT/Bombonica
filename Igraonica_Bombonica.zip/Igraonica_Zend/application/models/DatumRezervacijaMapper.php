<?php

class Application_Model_DatumRezervacijaMapper {

    protected $_dbTable;

    public function get_dbTable() {
        if (null == $this->_dbTable) {
            $this->set_dbTable("Application_Model_DbTable_DatumRezervacija");
        }
        return $this->_dbTable;
    }

    public function set_dbTable($dbTable) {
        if (is_string($dbTable)) {
            $dbTable = new $dbTable();
        }
        if (!$dbTable instanceof Zend_Db_Table_Abstract) {
            throw new Exception("Nepostojeci table geteway");
        }
        $this->_dbTable = $dbTable;
        return $this;
    }

    //TODO insert, update, delete itd
    public function fetchAll() {
        $sviKorisnici = $this->get_dbTable()->fetchAll();
        $entries = array();
        foreach ($sviKorisnici as $row) {
            $output = new Application_Model_DatumRezervacija();
            $output->setId_datum($row->id_datum)
                    ->setDatum_rezervacije($row->datum_rezervacije);
            $entries[] = $output;
        }
        return $entries;
    }
    
    public function fetchDatum() {
        $sviKorisnici = $this->get_dbTable()->fetchAll();
        $entries = array();
        foreach ($sviKorisnici as $row) {
            $output = new Application_Model_DatumRezervacija();
            $output->setId_datum($row->id_datum)
                    ->setDatum_rezervacije($row->datum_rezervacije);
            $entries[$output->getId_datum()] = $output->getDatum_rezervacije()."";
        }
        return $entries;
    }

    public function save(Application_Model_DatumRezervacija $T) {
        $data = array(
            'datum_rezervacije' => $T->getDatum_rezervacije(),
        );

        if (null === ($id = $T->getId_termin())) {
            unset($data['id']);
            $this->get_dbTable()->insert($data);
        } else {
            $this->get_dbTable()->update($data, array('id_datum = ?' => $id));
        }
    }

    public function find($id, Application_Model_DatumRezervacija $T) {
        $result = $this->get_dbTable()->find($id);
        if (0 == count($result)) {
            return;
        }
        $row = $result->current();
        $T->setId_datum($row->id_datum)
                ->setDatum_rezervacije($row->datum_rezervacije);
    }

}
