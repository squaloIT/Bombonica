<?php

class Application_Model_Korisnik
{
    public $id_korisnik;
    public $username;
    private $password;
    private $email;
    private $phoneNumber;
    private $address;
    private $status;
    private $id_uloga;   

    public function getId_korisnik() {
        return $this->id_korisnik;
    }

    public function getUsername() {
        return $this->username;
    }

    public function getPassword() {
        return $this->password;
    }

    public function getEmail() {
        return $this->email;
    }

    public function getPhoneNumber() {
        return $this->phoneNumber;
    }

    public function getAddress() {
        return $this->address;
    }

    public function getStatus() {
        return $this->status;
    }

    public function getId_uloga() {
        return $this->id_uloga;
    }

    public function setId_korisnik($id_korisnik) {
        $this->id_korisnik = $id_korisnik;
        return $this;
    }

    public function setUsername($username) {
        $this->username = $username;
        return $this;
    }

    public function setPassword($password) {
        $this->password = $password;
        return $this;
    }

    public function setEmail($email) {
        $this->email = $email;
        return $this;
    }

    public function setPhoneNumber($phoneNumber) {
        $this->phoneNumber = $phoneNumber;
        return $this;
    }

    public function setAddress($address) {
        $this->address = $address;
        return $this;
    }

    public function setStatus($status) {
        $this->status = $status;
        return $this;
    }

    public function setId_uloga($id_uloga) {
        $this->id_uloga = $id_uloga;
        return $this;
    }


}

