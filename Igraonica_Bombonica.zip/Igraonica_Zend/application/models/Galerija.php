<?php

class Application_Model_Galerija
{
    private $id_galerija;
    private $nazivGalerije;
    
    public function getId_galerija() {
        return $this->id_galerija;
    }

    public function getNaziv() {
        return $this->nazivGalerije;
    }

    public function setId_galerija($id_galerija) {
        $this->id_galerija = $id_galerija;
        return $this;
    }

    public function setNaziv($naziv) {
        $this->nazivGalerije = $naziv;
        return $this;
    }



}

