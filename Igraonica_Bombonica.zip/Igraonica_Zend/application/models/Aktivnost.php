<?php

class Application_Model_Aktivnost
{
    public $id_aktivnost;
    public $naslov;
    public $tekst;
    public $datum_odrzavanja;
    public $vreme;
    public $mesto;
    
    public function getId_aktivnost() {
        return $this->id_aktivnost;
    }

    public function getNaslov() {
        return $this->naslov;
    }

    public function getTekst() {
        return $this->tekst;
    }

    public function getDatum_odrzavanja() {
        return $this->datum_odrzavanja;
    }

    public function getVreme() {
        return $this->vreme;
    }

    public function getMesto() {
        return $this->mesto;
    }

    public function setId_aktivnost($id_aktivnost) {
        $this->id_aktivnost = $id_aktivnost;
        return $this;
    }

    public function setNaslov($naslov) {
        $this->naslov = $naslov;
        return $this;
    }

    public function setTekst($tekst) {
        $this->tekst = $tekst;
        return $this;
    }

    public function setDatum_odrzavanja($datum_odrzavanja) {
        $this->datum_odrzavanja = $datum_odrzavanja;
        return $this;
    }

    public function setVreme($vreme) {
        $this->vreme = $vreme;
        return $this;
    }

    public function setMesto($mesto) {
        $this->mesto = $mesto;
        return $this;
    }



}

