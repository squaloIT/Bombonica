<?php

class Application_Model_GalerijaMapper {

    protected $_dbTable;

    public function get_dbTable() {
        if (null == $this->_dbTable) {
            $this->set_dbTable("Application_Model_DbTable_Galerija");
        }
        return $this->_dbTable;
    }

    public function set_dbTable($dbTable) {
        if (is_string($dbTable)) {
            $dbTable = new $dbTable();
        }
        if (!$dbTable instanceof Zend_Db_Table_Abstract) {
            throw new Exception("Nepostojeci table gateway");
        }
        $this->_dbTable = $dbTable;
        return $this;
    }

    //TODO insert, update, delete itd

    public function fetchAll() {
        $sveGalerije = $this->get_dbTable()->fetchAll();
        $entries = array();
        foreach ($sveGalerije as $row) {
            $output = new Application_Model_Galerija();
            $output->setId_galerija($row->id_galerija)
                    ->setNaziv($row->nazivGalerije);
            $entries[] = $output;
        }
        return $entries;
    }
    
    public function fetchAllForDDL() {
        $sveGalerije = $this->get_dbTable()->fetchAll();
        $entries = array();
        foreach ($sveGalerije as $row) {
            $output = new Application_Model_Galerija();
            $output->setId_galerija($row->id_galerija)
                    ->setNaziv($row->nazivGalerije);
            $entries[$output->getId_galerija()] = $output->getNaziv();
        }
        return $entries;
    }
    
    
    public function save(Application_Model_Galerija $galerija) {
        $data = array(
            'naziv' => $galerija->getNaziv(),
        );

        if (null === ($id = $galerija->getId_galerija())) {
            unset($data['id']);
            $this->get_dbTable()->insert($data);
        } else {
            $this->get_dbTable()->update($data, array('id_galerija = ?' => $id));
        }
    }

    public function find($id, Application_Model_Galerija $galerija) {
        $result = $this->get_dbTable()->find($id);
        if (0 == count($result)) {
            return;
        }
        $row = $result->current();
        $galerija->setId_galerija($row->id_galerija)
                ->setNaziv($row->nazivGalerije);
    }

}
