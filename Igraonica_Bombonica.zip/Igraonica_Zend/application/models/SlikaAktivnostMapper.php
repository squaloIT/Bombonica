<?php

class Application_Model_SlikaAktivnostMapper {

    protected $_dbTable;

    public function get_dbTable() {
        if (null == $this->_dbTable) {
            $this->set_dbTable("Application_Model_DbTable_SlikaAktivnost");
        }
        return $this->_dbTable;
    }

    public function set_dbTable($dbTable) {
        if (is_string($dbTable)) {
            $dbTable = new $dbTable();
        }
        if (!$dbTable instanceof Zend_Db_Table_Abstract) {
            throw new Exception("Nepostojeci table gateway");
        }
        $this->_dbTable = $dbTable;
        return $this;
    }

    //TODO insert, update, delete itd

    public function fetchAll() {
        $sveSlikeAktivnosti = $this->get_dbTable()->fetchAll();
        $entries = array();
        foreach ($sveSlikeAktivnosti as $row) {
            $output = new Application_Model_SlikaAktivnost();
            $output->setId_slika($row->id_slika)
                    ->setPutanja($row->putanja)
                    ->setNaziv($row->naziv)
                    ->setId_aktivnost($row->id_aktivnost);
            $entries[] = $output;
        }
        return $entries;
    }

    public function save(Application_Model_SlikaAktivnost $SlikaAktivnost) {
        $data = array(
            'putanja' => $SlikaAktivnost->getPutanja(),
            'naziv' => $SlikaAktivnost->getNaziv(),
            'id_aktivnost' => $SlikaAktivnost->getId_aktivnost(),
        );

        if (null === ($id = $SlikaAktivnost->getId_slika())) {
            unset($data['id']);
            $this->get_dbTable()->insert($data);
        } else {
            $this->get_dbTable()->update($data, array('id_slika = ?' => $id));
        }
    }

    public function find($id, Application_Model_SlikaAktivnost $slikaAktivnost) {
        $result = $this->get_dbTable()->find($id);
        if (0 == count($result)) {
            return;
        }
        $row = $result->current();
        $slikaAktivnost->setId_slika($row->id_slika)
                ->setPutanja($row->putanja)
                ->setNaziv($row->naziv)
                ->setId_aktivnost($row->id_aktivnost);
    }

}
