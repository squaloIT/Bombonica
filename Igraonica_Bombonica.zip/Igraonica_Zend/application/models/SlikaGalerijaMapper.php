<?php

class Application_Model_SlikaGalerijaMapper {

    protected $_dbTable;

    public function get_dbTable() {
        if (null == $this->_dbTable) {
            $this->set_dbTable("Application_Model_DbTable_SlikaGalerija");
        }
        return $this->_dbTable;
    }

    public function set_dbTable($dbTable) {
        if (is_string($dbTable)) {
            $dbTable = new $dbTable();
        }
        if (!$dbTable instanceof Zend_Db_Table_Abstract) {
            throw new Exception("Nepostojeci table gateway");
        }
        $this->_dbTable = $dbTable;
        return $this;
    }

    //TODO insert, update, delete itd

    public function fetchAll() {
//           $select = $this->getDbTable()->select(Zend_Db_Table::SELECT_WITH_FROM_PART);
//        $select->setIntegrityCheck(false)
//                ->join('users', 'users.id_user = messages.id_sender')
//                ->join('inbox', 'inbox.id_message = messages.id_message')
//                ->where('inbox.id_receiver = ?', $id);
//        $rows = $this->getDbTable()->fetchAll($select);
//        return $rows;
        $sveSlikaGalerija = $this->get_dbTable()->select(Zend_Db_Table::SELECT_WITH_FROM_PART);
        $sveSlikaGalerija->setIntegrityCheck(false)
                ->join('galerija', 'slike_galerija.id_galerija = galerija.id_galerija');
        $rows = $this->get_dbTable()->fetchAll($sveSlikaGalerija);
        $entries = array();
        foreach ($rows as $row) {
            $output = new Application_Model_SlikaGalerija();
            $output->setId_slika($row->id_slika)
                    ->setPutanja($row->putanja)
                    ->setNaziv($row->naziv)
                    ->setGalerija($row->nazivGalerije)
                    ->setId_galerija($row->id_galerija);
            $entries[] = $output;
        }
        return $entries;
    }

    public function save(Application_Model_SlikaGalerija $slikaGalerija) {
        $data = array(
            'putanja' => $slikaGalerija->getPutanja(),
            'naziv' => $slikaGalerija->getNaziv(),
            'id_galerija' => $slikaGalerija->getId_galerija(),
        );

        if (null === ($id = $slikaGalerija->getId_slika())) {
            unset($data['id']);
            $this->get_dbTable()->insert($data);
        } else {
            $this->get_dbTable()->update($data, array('id_slika= ?' => $id));
        }
    }

    public function find($id, Application_Model_SlikaGalerija $slikaGalerija) {
        $result = $this->get_dbTable()->find($id);
        if (0 == count($result)) {
            return;
        }
        $row = $result->current();
        $slikaGalerija->setId_slika($row->id_slika)
                ->setPutanja($row->putanja)
                ->setNaziv($row->naziv)
                ->setId_galerija($row->id_galerija);
    }

}
