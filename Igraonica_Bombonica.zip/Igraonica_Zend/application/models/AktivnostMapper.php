<?php

class Application_Model_AktivnostMapper {

    protected $_dbTable;

    public function get_dbTable() {
        if (null == $this->_dbTable) {
            $this->set_dbTable("Application_Model_DbTable_Aktivnost");
        }
        return $this->_dbTable;
    }

    public function set_dbTable($dbTable) {
        if (is_string($dbTable)) {
            $dbTable = new $dbTable();
        }
        if (!$dbTable instanceof Zend_Db_Table_Abstract) {
            throw new Exception("Nepostojeci table gateway");
        }
        $this->_dbTable = $dbTable;
        return $this;
    }

    //TODO insert, update, delete itd

    public function fetchAll() {
        $select = $this->get_DbTable()->select();
        $select->setIntegrityCheck(false)
                ->where("datum_odrzavanja > SYSDATE()")
                ->order("datum_odrzavanja ASC");
        
        $sveAktivnosti= $this->get_dbTable()->fetchAll($select);
        $entries = array();
        foreach ($sveAktivnosti as $row) {
            $output = new Application_Model_Aktivnost();
            $output->setId_aktivnost($row->id_aktivnost)
                    ->setNaslov($row->naslov)
                    ->setTekst($row->tekst)
                    ->setDatum_odrzavanja($row->datum_odrzavanja)
                    ->setVreme($row->vreme)
                    ->setMesto($row->mesto);
            $entries[] = $output;
        }
        return $entries;
    }
    public function fetchTopThree() {
        //$query="SELECT * FROM aktivnosti Order BY datum_odrzavanja DESC LIMIT 3 ";
        $select = $this->get_DbTable()->select();
        $select->setIntegrityCheck(false)
                ->where("datum_odrzavanja < SYSDATE()")
                ->order("datum_odrzavanja DESC")
                ->limit("3");
        $sveAktivnosti= $this->get_dbTable()->fetchAll($select); //ON KAO PARAMETAR UZIMA WHERE ARRAY PRVI MOZDA OVDE GRESKA
        $entries = array();
        foreach ($sveAktivnosti as $row) {
            $output = new Application_Model_Aktivnost();
            $output->setId_aktivnost($row->id_aktivnost)
                    ->setNaslov($row->naslov)
                    ->setTekst($row->tekst)
                    ->setDatum_odrzavanja($row->datum_odrzavanja)
                    ->setVreme($row->vreme)
                    ->setMesto($row->mesto);
            $entries[] = $output;
        }
        return $entries;
    }

    public function save(Application_Model_Aktivnost $aktivnost) {
        $data = array(
            'naslov' => $aktivnost->getNaslov(),
            'tekst' => $aktivnost->getTekst(),
            'datum_odrzavanja' => $aktivnost->getDatum_odrzavanja(),
            'vreme' => $aktivnost->getVreme(),
            'mesto' => $aktivnost->getMesto(),
        );

        if (null === ($id = $aktivnost->getId_aktivnost())) {
            unset($data['id']);
            $this->get_dbTable()->insert($data);
        } else {
            $this->get_dbTable()->update($data, array('id_aktivnost = ?' => $id));
        }
    }

    public function find($id, Application_Model_Aktivnost $aktivnost) {
        $result = $this->get_dbTable()->find($id);
        if (0 == count($result)) {
            return;
        }
        $row = $result->current();
        $aktivnost->setId_aktivnost($row->id_aktivnost)
                ->setNaslov($row->naslov)
                ->setTekst($row->tekst)
                ->setDatum_odrzavanja($row->datum_odrzavanja)
                ->setVreme($row->vreme)
                ->setMesto($row->mesto);
        return $aktivnost;
    }

}
