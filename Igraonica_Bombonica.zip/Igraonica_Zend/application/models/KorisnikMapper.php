<?php

class Application_Model_KorisnikMapper {

    protected $_dbTable;

    public function get_dbTable() {
        if (null == $this->_dbTable) {
            $this->set_dbTable("Application_Model_DbTable_Korisnik");
        }
        return $this->_dbTable;
    }

    public function set_dbTable($dbTable) {
        if (is_string($dbTable)) {
            $dbTable = new $dbTable();
        }
        if (!$dbTable instanceof Zend_Db_Table_Abstract) {
            throw new Exception("Nepostojeci table geteway");
        }
        $this->_dbTable = $dbTable;
        return $this;
    }

    //TODO insert, update, delete itd

    public function fetchAll() {
        $sviKorisnici = $this->get_dbTable()->fetchAll();
        $entries = array();
        foreach ($sviKorisnici as $row) {
            $output = new Application_Model_Korisnik();
            $output->setId_korisnik($row->id_korisnik)
                    ->setUsername($row->username)
                    ->setPassword($row->password)
                    ->setEmail($row->email)
                    ->setPhoneNumber($row->broj_telefona)
                    ->setAddress($row->adresa)
                    ->setStatus($row->status)
                    ->setId_uloga($row->id_uloga);
            $entries[] = $output;
        }
        return $entries;
    }

    public function save(Application_Model_Korisnik $korisnik) {
        $data = array(
            'username' => $korisnik->getUsername(),
            'password' => $korisnik->getPassword(),
            'broj_telefona'=>$korisnik->getPhoneNumber(),
            'adresa'=>$korisnik->getAddress(),
            'email'=>$korisnik->getEmail(),
            'status'=>0,
            'id_uloga' => 2,
        );

        if (null === ($id = $korisnik->getId_korisnik())) {
            unset($data['id']);
            return $this->get_dbTable()->insert($data);
            
        } else {
            $this->get_dbTable()->update($data, array('id_korisnik = ?' => $id));
        }
    }

    public function find($id, Application_Model_Korisnik $korisnik) {
        $result = $this->get_dbTable()->find($id);
        if (0 == count($result)) {
            return;
        }
        $row = $result->current();
        $korisnik->setId_korisnik($row->id_korisnik)
                  ->setEmail($row->email)
                  ->setUsername($row->username)
                  ->setPassword($row->password)
                  ->setPhoneNumber($row->broj_telefona)
                  ->setAddress($row->adresa)
                  ->setStatus($row->status)
                  ->setId_uloga($row->id_uloga);
    }

}
