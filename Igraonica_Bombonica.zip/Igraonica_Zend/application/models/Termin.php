<?php

class Application_Model_Termin
{
    public $id_termin;
    public $trajanje_termina;
    
    public function getId_termin() {
        return $this->id_termin;
    }

    public function getTrajanje_termina() {
        return $this->trajanje_termina;
    }

    public function setId_termin($id_termin) {
        $this->id_termin = $id_termin;
        return $this;
    }

    public function setTrajanje_termina($trajanje_termina) {
        $this->trajanje_termina = $trajanje_termina;
        return $this;
    }
}

