<?php

class Application_Model_TerminMapper {

    protected $_dbTable;

    public function get_dbTable() {
        if (null == $this->_dbTable) {
            $this->set_dbTable("Application_Model_DbTable_Termin");
        }
        return $this->_dbTable;
    }

    public function set_dbTable($dbTable) {
        if (is_string($dbTable)) {
            $dbTable = new $dbTable();
        }
        if (!$dbTable instanceof Zend_Db_Table_Abstract) {
            throw new Exception("Nepostojeci table geteway");
        }
        $this->_dbTable = $dbTable;
        return $this;
    }

    //TODO insert, update, delete itd
    public function fetchAll() {
        $sviKorisnici = $this->get_dbTable()->fetchAll();
        $entries = array();
        foreach ($sviKorisnici as $row) {
            $output = new Application_Model_Termin();
            $output->setId_termin($row->id_termin)
                    ->setTrajanje_termina($row->trajanje_termina);
            $entries[] = $output;
        }
        return $entries;
    }

    public function fetchTermin($nizZauzetihTermina) {
//         $select = $this->getDbTable()->select(Zend_Db_Table::SELECT_WITH_FROM_PART);
//        $select->setIntegrityCheck(false)
//                ->join('users', 'users.id_user = messages.id_sender')
//                ->join('inbox', 'inbox.id_message = messages.id_message')
//                ->where('inbox.id_receiver = ?', $id);
//        $rows = $this->getDbTable()->fetchAll($select);
        $where = "";
        if (count($nizZauzetihTermina) != 0) {
            for ($i = 0; $i < count($nizZauzetihTermina); $i++) {
                if ($i == 0) {
                    $where.=" id_termin != " . $nizZauzetihTermina[$i];
                } else {
                    $where.=" AND id_termin != " . $nizZauzetihTermina[$i];
                }
            }
        }

        $select = $this->get_DbTable()->select();
        $select->setIntegrityCheck(false);
        if ($where != "") {
            $select->where($where);
        }
        $sviTermini = $this->get_dbTable()->fetchAll($select);

        $entries = array();
        if (!empty($sviTermini) && $sviTermini != null) {
            foreach ($sviTermini as $row) {
                $output = new Application_Model_Termin();
                $output->setId_termin($row->id_termin)
                        ->setTrajanje_termina($row->trajanje_termina);
                $entries[$output->getId_termin()] = $output->getTrajanje_termina() . "";
            }
        }

        return $entries;
    }

    public function save(Application_Model_Termin $T) {
        $data = array(
            'trajanje_termina' => $T->getTrajanje_termina(),
        );

        if (null === ($id = $T->getId_termin())) {
            unset($data['id']);
            return $this->get_dbTable()->insert($data);
        } else {
            return $this->get_dbTable()->update($data, array('id_termin = ?' => $id));
        }
    }

    public function find($id, Application_Model_Termin $T) {
        $result = $this->get_dbTable()->find($id);
        if (0 == count($result)) {
            return;
        }
        $row = $result->current();
        $T->setId_termin($row->id_termin)
                ->setTrajanje_termina($row->trajanje_termina);
    }

}
