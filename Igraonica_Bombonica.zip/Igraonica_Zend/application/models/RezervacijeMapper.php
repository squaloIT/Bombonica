<?php

class Application_Model_RezervacijeMapper {

    protected $_dbTable;

    public function get_dbTable() {
        if (null == $this->_dbTable) {
            $this->set_dbTable("Application_Model_DbTable_Rezervacije");
        }
        return $this->_dbTable;
    }

    public function set_dbTable($dbTable) {
        if (is_string($dbTable)) {
            $dbTable = new $dbTable();
        }
        if (!$dbTable instanceof Zend_Db_Table_Abstract) {
            throw new Exception("Nepostojeci table geteway");
        }
        $this->_dbTable = $dbTable;
        return $this;
    }

    //TODO insert, update, delete itd

    public function fetchAll() {
        $sviKorisnici = $this->get_dbTable()->fetchAll();
        $entries = array();
        foreach ($sviKorisnici as $row) {
            $output = new Application_Model_Rezervacije();
            $output->setId_rezervacija($row->id_rezervacija)
                    ->setUsername($row->username)
                    ->setEmail($row->email)
                    ->setSlavljenik($row->slavljenik)
                    ->setId_termin($row->id_termin)
                    ->setId_datum($row->id_datum);
            $entries[] = $output;
        }
        return $entries;
    }

    public function save(Application_Model_Rezervacije $T) {
        $data = array(
            'username' => $T->getUsername(),
            'email' => $T->getEmail(),
            'slavljenik' => $T->getSlavljenik(),
            'id_termin' => $T->getId_termin(),
            'id_datum' => $T->getId_datum(),
        );

        if (null === ($id = $T->getId_rezervacija())) {
            unset($data['id']);
            return $this->get_dbTable()->insert($data);
        } else {
            return $this->get_dbTable()->update($data, array('id_rezervacija = ?' => $id));
        }
    }

    public function find($id, Application_Model_Rezervacije $T) {
        $result = $this->get_dbTable()->find($id);
        if (0 == count($result)) {
            return;
        }
        $row = $result->current();
        $T->setId_rezervacija($row->id_rezervacija)
                ->setUsername($row->username)
                ->setEmail($row->email)
                ->setSlavljenik($row->slavljenik)
                ->setId_termin($row->id_termin)
                ->setId_datum($row->id_datum);
    }

    public function findDatum($idDatum, Application_Model_Termin $T) {
        
        $this->set_dbTable("Application_Model_DbTable_Rezervacije");
        $select = $this->get_dbTable()->select();
        $select->setIntegrityCheck(false)
                ->where('id_datum = ?', intval($idDatum));
        $result = $this->get_dbTable()->fetchAll($select);
        if (0 == count($result)) {
            return null;
        }

        $entries = array();
        foreach ($result as $row) {
            $output = new Application_Model_Termin();
            $output->setId_termin($row->id_termin);
            $entries[] = $output;
        }
        return $entries;

    }

}
